package com.android.tools.fd.runtime;

import android.app.Activity;
import android.app.Application;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.util.Log;
import dalvik.system.DexClassLoader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class Server
{
  private static final boolean POST_ALIVE_STATUS = false;
  private static final boolean RESTART_LOCALLY = false;
  private static int sWrongTokenCount;
  private final Application mApplication;
  private LocalServerSocket mServerSocket;
  
  private Server(String paramString, Application paramApplication)
  {
    this.mApplication = paramApplication;
    try
    {
      this.mServerSocket = new LocalServerSocket(paramString);
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Starting server socket listening for package " + paramString + " on " + this.mServerSocket.getLocalSocketAddress());
      }
      startServer();
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Started server for package " + paramString);
      }
      return;
    }
    catch (IOException paramApplication)
    {
      Log.e("InstantRun", "IO Error creating local socket at " + paramString, paramApplication);
    }
  }
  
  public static void create(String paramString, Application paramApplication)
  {
    new Server(paramString, paramApplication);
  }
  
  private static void handleColdSwapPatch(ApplicationPatch paramApplicationPatch)
  {
    if (paramApplicationPatch.path.startsWith("slice-"))
    {
      paramApplicationPatch = FileManager.writeDexShard(paramApplicationPatch.getBytes(), paramApplicationPatch.path);
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Received dex shard " + paramApplicationPatch);
      }
    }
  }
  
  private int handleHotSwapPatch(int paramInt, ApplicationPatch paramApplicationPatch)
  {
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "Received incremental code patch");
    }
    for (;;)
    {
      try
      {
        paramApplicationPatch = FileManager.writeTempDexFile(paramApplicationPatch.getBytes());
        if (paramApplicationPatch == null)
        {
          Log.e("InstantRun", "No file to write the code to");
          return paramInt;
        }
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Reading live code from " + paramApplicationPatch);
        }
        localObject = FileManager.getNativeLibraryFolder().getPath();
        localObject = Class.forName("com.android.tools.fd.runtime.AppPatchesLoaderImpl", true, new DexClassLoader(paramApplicationPatch, this.mApplication.getCacheDir().getPath(), (String)localObject, getClass().getClassLoader()));
      }
      catch (Throwable paramApplicationPatch)
      {
        Object localObject;
        boolean bool;
        Log.e("InstantRun", "Couldn't apply code changes", paramApplicationPatch);
        paramInt = 3;
        continue;
      }
      try
      {
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Got the patcher class " + localObject);
        }
        paramApplicationPatch = (PatchesLoader)((Class)localObject).newInstance();
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Got the patcher instance " + paramApplicationPatch);
        }
        localObject = (String[])((Class)localObject).getDeclaredMethod("getPatchedClasses", new Class[0]).invoke(paramApplicationPatch, new Object[0]);
        if (Log.isLoggable("InstantRun", 2))
        {
          Log.v("InstantRun", "Got the list of classes ");
          int j = localObject.length;
          int i = 0;
          if (i < j)
          {
            String str = localObject[i];
            Log.v("InstantRun", "class " + str);
            i += 1;
            continue;
          }
        }
        bool = paramApplicationPatch.load();
        if (!bool) {
          paramInt = 3;
        }
      }
      catch (Exception paramApplicationPatch)
      {
        Log.e("InstantRun", "Couldn't apply code changes", paramApplicationPatch);
        paramApplicationPatch.printStackTrace();
        paramInt = 3;
      }
    }
    return paramInt;
  }
  
  private int handlePatches(List<ApplicationPatch> paramList, boolean paramBoolean, int paramInt)
  {
    if (paramBoolean) {
      FileManager.startUpdate();
    }
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = (ApplicationPatch)localIterator.next();
      String str = ((ApplicationPatch)localObject).getPath();
      if (str.endsWith(".dex"))
      {
        handleColdSwapPatch((ApplicationPatch)localObject);
        int j = 0;
        localObject = paramList.iterator();
        do
        {
          i = j;
          if (!((Iterator)localObject).hasNext()) {
            break;
          }
        } while (!((ApplicationPatch)((Iterator)localObject).next()).getPath().equals("classes.dex.3"));
        int i = 1;
        if (i == 0) {
          paramInt = 3;
        }
      }
      else if (str.equals("classes.dex.3"))
      {
        paramInt = handleHotSwapPatch(paramInt, (ApplicationPatch)localObject);
      }
      else if (isResourcePath(str))
      {
        paramInt = handleResourcePatch(paramInt, (ApplicationPatch)localObject, str);
      }
    }
    if (paramBoolean) {
      FileManager.finishUpdate(true);
    }
    return paramInt;
  }
  
  private static int handleResourcePatch(int paramInt, ApplicationPatch paramApplicationPatch, String paramString)
  {
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "Received resource changes (" + paramString + ")");
    }
    FileManager.writeAaptResources(paramString, paramApplicationPatch.getBytes());
    return Math.max(paramInt, 2);
  }
  
  private static boolean hasResources(List<ApplicationPatch> paramList)
  {
    paramList = paramList.iterator();
    while (paramList.hasNext()) {
      if (isResourcePath(((ApplicationPatch)paramList.next()).getPath())) {
        return true;
      }
    }
    return false;
  }
  
  private static boolean isResourcePath(String paramString)
  {
    return (paramString.equals("resources.ap_")) || (paramString.startsWith("res/"));
  }
  
  private void restart(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "Finished loading changes; update mode =" + paramInt);
    }
    Object localObject1;
    if ((paramInt == 0) || (paramInt == 1))
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Applying incremental code without restart");
      }
      if (paramBoolean2)
      {
        localObject1 = Restarter.getForegroundActivity(this.mApplication);
        if (localObject1 == null) {
          break label89;
        }
        Restarter.showToast((Activity)localObject1, "Applied code changes without activity restart");
      }
    }
    label88:
    label89:
    label427:
    label442:
    label462:
    do
    {
      do
      {
        break label88;
        do
        {
          return;
        } while (!Log.isLoggable("InstantRun", 2));
        Log.v("InstantRun", "Couldn't show toast: no activity found");
        return;
        localObject1 = Restarter.getActivities(this.mApplication, false);
        i = paramInt;
        Object localObject2;
        if (paramBoolean1)
        {
          i = paramInt;
          if (paramInt == 2)
          {
            localObject2 = FileManager.getExternalResourceFile();
            if (Log.isLoggable("InstantRun", 2)) {
              Log.v("InstantRun", "About to update resource file=" + localObject2 + ", activities=" + localObject1);
            }
            if (localObject2 == null) {
              break label427;
            }
            localObject2 = ((File)localObject2).getPath();
            MonkeyPatcher.monkeyPatchApplication(this.mApplication, null, null, (String)localObject2);
            MonkeyPatcher.monkeyPatchExistingResources(this.mApplication, (String)localObject2, (Collection)localObject1);
          }
        }
        for (i = paramInt;; i = 3)
        {
          localObject1 = Restarter.getForegroundActivity(this.mApplication);
          paramInt = i;
          if (i != 2) {
            break label462;
          }
          if (localObject1 == null) {
            break label442;
          }
          if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Restarting activity only!");
          }
          int j = 0;
          paramInt = 0;
          i = j;
          try
          {
            localObject2 = localObject1.getClass().getMethod("onHandleCodeChange", new Class[] { Long.TYPE }).invoke(localObject1, new Object[] { Long.valueOf(0L) });
            i = j;
            if (Log.isLoggable("InstantRun", 2))
            {
              i = j;
              Log.v("InstantRun", "Activity " + localObject1 + " provided manual restart method; return " + localObject2);
            }
            i = j;
            if (Boolean.TRUE.equals(localObject2))
            {
              i = 1;
              j = 1;
              paramInt = j;
              if (paramBoolean2)
              {
                Restarter.showToast((Activity)localObject1, "Applied changes");
                paramInt = j;
              }
            }
          }
          catch (Throwable localThrowable)
          {
            for (;;)
            {
              paramInt = i;
            }
          }
          if (paramInt != 0) {
            break;
          }
          if (paramBoolean2) {
            Restarter.showToast((Activity)localObject1, "Applied changes, restarted activity");
          }
          Restarter.restartActivityOnUiThread((Activity)localObject1);
          return;
          Log.e("InstantRun", "No resource file found to apply");
        }
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "No activity found, falling through to do a full app restart");
        }
        paramInt = 3;
        if (paramInt == 3) {
          break;
        }
      } while (!Log.isLoggable("InstantRun", 6));
      Log.e("InstantRun", "Unexpected update mode: " + paramInt);
      return;
    } while (!Log.isLoggable("InstantRun", 2));
    Log.v("InstantRun", "Waiting for app to be killed and restarted by the IDE...");
  }
  
  private void startServer()
  {
    try
    {
      new Thread(new SocketServerThread(null)).start();
      return;
    }
    catch (Throwable localThrowable)
    {
      while (!Log.isLoggable("InstantRun", 6)) {}
      Log.e("InstantRun", "Fatal error starting Instant Run server", localThrowable);
    }
  }
  
  private class SocketServerReplyThread
    extends Thread
  {
    private final LocalSocket mSocket;
    
    SocketServerReplyThread(LocalSocket paramLocalSocket)
    {
      this.mSocket = paramLocalSocket;
    }
    
    private boolean authenticate(DataInputStream paramDataInputStream)
      throws IOException
    {
      long l = paramDataInputStream.readLong();
      if (l != AppInfo.token)
      {
        Log.w("InstantRun", "Mismatched identity token from client; received " + l + " and expected " + AppInfo.token);
        Server.access$208();
        return false;
      }
      return true;
    }
    
    private void handle(DataInputStream paramDataInputStream, DataOutputStream paramDataOutputStream)
      throws IOException
    {
      long l1 = paramDataInputStream.readLong();
      if (l1 != 890269988L)
      {
        Log.w("InstantRun", "Unrecognized header format " + Long.toHexString(l1));
        return;
      }
      int i = paramDataInputStream.readInt();
      paramDataOutputStream.writeInt(4);
      boolean bool1;
      if (i != 4)
      {
        Log.w("InstantRun", "Mismatched protocol versions; app is using version 4 and tool is using version " + i);
        return;
        if (Restarter.getForegroundActivity(Server.this.mApplication) == null) {
          break label246;
        }
        bool1 = true;
        paramDataOutputStream.writeBoolean(bool1);
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Received Ping message from the IDE; returned active = " + bool1);
        }
      }
      for (;;)
      {
        i = paramDataInputStream.readInt();
        label246:
        Object localObject1;
        Object localObject2;
        switch (i)
        {
        case 2: 
        default: 
          if (!Log.isLoggable("InstantRun", 6)) {
            break;
          }
          Log.e("InstantRun", "Unexpected message type: " + i);
          return;
        case 7: 
          if (!Log.isLoggable("InstantRun", 2)) {
            break;
          }
          Log.v("InstantRun", "Received EOF from the IDE");
          return;
          bool1 = false;
          break;
        case 3: 
          localObject1 = paramDataInputStream.readUTF();
          l1 = FileManager.getFileSize((String)localObject1);
          paramDataOutputStream.writeLong(l1);
          if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Received path-exists(" + (String)localObject1 + ") from the " + "IDE; returned size=" + l1);
          }
          break;
        case 4: 
          l1 = System.currentTimeMillis();
          localObject1 = paramDataInputStream.readUTF();
          localObject2 = FileManager.getCheckSum((String)localObject1);
          if (localObject2 != null)
          {
            paramDataOutputStream.writeInt(localObject2.length);
            paramDataOutputStream.write((byte[])localObject2);
            if (Log.isLoggable("InstantRun", 2))
            {
              long l2 = System.currentTimeMillis();
              localObject2 = new BigInteger(1, (byte[])localObject2).toString(16);
              Log.v("InstantRun", "Received checksum(" + (String)localObject1 + ") from the " + "IDE: took " + (l2 - l1) + "ms to compute " + (String)localObject2);
            }
          }
          else
          {
            paramDataOutputStream.writeInt(0);
            if (Log.isLoggable("InstantRun", 2)) {
              Log.v("InstantRun", "Received checksum(" + (String)localObject1 + ") from the " + "IDE: returning <null>");
            }
          }
          break;
        case 5: 
          if (!authenticate(paramDataInputStream)) {
            break;
          }
          localObject1 = Restarter.getForegroundActivity(Server.this.mApplication);
          if (localObject1 != null)
          {
            if (Log.isLoggable("InstantRun", 2)) {
              Log.v("InstantRun", "Restarting activity per user request");
            }
            Restarter.restartActivityOnUiThread((Activity)localObject1);
          }
          break;
        case 1: 
          if (!authenticate(paramDataInputStream)) {
            break;
          }
          localObject1 = ApplicationPatch.read(paramDataInputStream);
          if (localObject1 != null)
          {
            bool1 = Server.hasResources((List)localObject1);
            i = paramDataInputStream.readInt();
            i = Server.this.handlePatches((List)localObject1, bool1, i);
            boolean bool2 = paramDataInputStream.readBoolean();
            paramDataOutputStream.writeBoolean(true);
            Server.this.restart(i, bool1, bool2);
          }
          break;
        case 6: 
          localObject1 = paramDataInputStream.readUTF();
          localObject2 = Restarter.getForegroundActivity(Server.this.mApplication);
          if (localObject2 != null) {
            Restarter.showToast((Activity)localObject2, (String)localObject1);
          } else if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Couldn't show toast (no activity) : " + (String)localObject1);
          }
          break;
        }
      }
    }
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: new 27	java/io/DataInputStream
      //   3: dup
      //   4: aload_0
      //   5: getfield 20	com/android/tools/fd/runtime/Server$SocketServerReplyThread:mSocket	Landroid/net/LocalSocket;
      //   8: invokevirtual 218	android/net/LocalSocket:getInputStream	()Ljava/io/InputStream;
      //   11: invokespecial 221	java/io/DataInputStream:<init>	(Ljava/io/InputStream;)V
      //   14: astore_3
      //   15: new 85	java/io/DataOutputStream
      //   18: dup
      //   19: aload_0
      //   20: getfield 20	com/android/tools/fd/runtime/Server$SocketServerReplyThread:mSocket	Landroid/net/LocalSocket;
      //   23: invokevirtual 225	android/net/LocalSocket:getOutputStream	()Ljava/io/OutputStream;
      //   26: invokespecial 228	java/io/DataOutputStream:<init>	(Ljava/io/OutputStream;)V
      //   29: astore_1
      //   30: aload_0
      //   31: aload_3
      //   32: aload_1
      //   33: invokespecial 230	com/android/tools/fd/runtime/Server$SocketServerReplyThread:handle	(Ljava/io/DataInputStream;Ljava/io/DataOutputStream;)V
      //   36: aload_3
      //   37: invokevirtual 233	java/io/DataInputStream:close	()V
      //   40: aload_1
      //   41: invokevirtual 234	java/io/DataOutputStream:close	()V
      //   44: return
      //   45: astore_2
      //   46: aload_3
      //   47: invokevirtual 233	java/io/DataInputStream:close	()V
      //   50: aload_1
      //   51: invokevirtual 234	java/io/DataOutputStream:close	()V
      //   54: aload_2
      //   55: athrow
      //   56: astore_1
      //   57: ldc 39
      //   59: iconst_2
      //   60: invokestatic 112	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   63: ifeq -19 -> 44
      //   66: ldc 39
      //   68: ldc -20
      //   70: aload_1
      //   71: invokestatic 239	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   74: pop
      //   75: return
      //   76: astore_2
      //   77: goto -37 -> 40
      //   80: astore_1
      //   81: return
      //   82: astore_3
      //   83: goto -33 -> 50
      //   86: astore_1
      //   87: goto -33 -> 54
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	90	0	this	SocketServerReplyThread
      //   29	22	1	localDataOutputStream	DataOutputStream
      //   56	15	1	localIOException1	IOException
      //   80	1	1	localIOException2	IOException
      //   86	1	1	localIOException3	IOException
      //   45	10	2	localObject	Object
      //   76	1	2	localIOException4	IOException
      //   14	33	3	localDataInputStream	DataInputStream
      //   82	1	3	localIOException5	IOException
      // Exception table:
      //   from	to	target	type
      //   30	36	45	finally
      //   0	30	56	java/io/IOException
      //   54	56	56	java/io/IOException
      //   36	40	76	java/io/IOException
      //   40	44	80	java/io/IOException
      //   46	50	82	java/io/IOException
      //   50	54	86	java/io/IOException
    }
  }
  
  private class SocketServerThread
    extends Thread
  {
    private SocketServerThread() {}
    
    public void run()
    {
      for (;;)
      {
        try
        {
          Object localObject = Server.this.mServerSocket;
          if (localObject == null) {
            return;
          }
          localObject = ((LocalServerSocket)localObject).accept();
          if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Received connection from IDE: spawning connection thread");
          }
          new Server.SocketServerReplyThread(Server.this, (LocalSocket)localObject).run();
          if (Server.sWrongTokenCount <= 50) {
            continue;
          }
          if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Stopping server: too many wrong token connections");
          }
          Server.this.mServerSocket.close();
          return;
        }
        catch (Throwable localThrowable) {}
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Fatal error accepting connection on local socket", localThrowable);
        }
      }
    }
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\Server.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */