package com.android.tools.fd.runtime;

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileManager
{
  public static final String CLASSES_DEX_SUFFIX = ".dex";
  private static final String FILE_NAME_ACTIVE = "active";
  private static final String FOLDER_NAME_LEFT = "left";
  private static final String FOLDER_NAME_RIGHT = "right";
  private static final String RELOAD_DEX_PREFIX = "reload";
  private static final String RESOURCE_FILE_NAME = "resources.ap_";
  private static final String RESOURCE_FOLDER_NAME = "resources";
  private static final boolean USE_EXTRACTED_RESOURCES = false;
  private static boolean sHavePurgedTempDexFolder;
  
  public static void checkInbox()
  {
    File localFile = new File(Paths.getInboxDirectory(AppInfo.applicationId));
    if (localFile.isDirectory())
    {
      localFile = new File(localFile, "resources.ap_");
      if (localFile.isFile())
      {
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Processing resource file from inbox (" + localFile + ")");
        }
        byte[] arrayOfByte = readRawBytes(localFile);
        if (arrayOfByte != null)
        {
          startUpdate();
          writeAaptResources("resources.ap_", arrayOfByte);
          finishUpdate(true);
          if ((!localFile.delete()) && (Log.isLoggable("InstantRun", 6))) {
            Log.e("InstantRun", "Couldn't remove inbox resource file: " + localFile);
          }
        }
      }
    }
  }
  
  private static void delete(File paramFile)
  {
    if (paramFile.isDirectory())
    {
      File[] arrayOfFile = paramFile.listFiles();
      if (arrayOfFile != null)
      {
        int j = arrayOfFile.length;
        int i = 0;
        while (i < j)
        {
          delete(arrayOfFile[i]);
          i += 1;
        }
      }
    }
    if (!paramFile.delete()) {
      Log.e("InstantRun", "Failed to delete file " + paramFile);
    }
  }
  
  /* Error */
  private static File[] extractSlices(File paramFile, File[] paramArrayOfFile, long paramLong)
  {
    // Byte code:
    //   0: ldc 64
    //   2: iconst_2
    //   3: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   6: ifeq +28 -> 34
    //   9: ldc 64
    //   11: new 72	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   18: ldc -126
    //   20: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: aload_0
    //   24: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   27: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   30: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   33: pop
    //   34: ldc -124
    //   36: ldc -122
    //   38: invokevirtual 140	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   41: astore 7
    //   43: aload 7
    //   45: ifnonnull +26 -> 71
    //   48: ldc 64
    //   50: bipush 6
    //   52: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   55: ifeq +11 -> 66
    //   58: ldc 64
    //   60: ldc -114
    //   62: invokestatic 115	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   65: pop
    //   66: iconst_0
    //   67: anewarray 38	java/io/File
    //   70: areturn
    //   71: new 144	java/util/ArrayList
    //   74: dup
    //   75: bipush 30
    //   77: invokespecial 147	java/util/ArrayList:<init>	(I)V
    //   80: astore 9
    //   82: new 149	java/util/HashSet
    //   85: dup
    //   86: bipush 30
    //   88: invokespecial 150	java/util/HashSet:<init>	(I)V
    //   91: astore 10
    //   93: new 152	java/util/zip/ZipInputStream
    //   96: dup
    //   97: aload 7
    //   99: invokespecial 155	java/util/zip/ZipInputStream:<init>	(Ljava/io/InputStream;)V
    //   102: astore 8
    //   104: sipush 2000
    //   107: newarray <illegal type>
    //   109: astore 11
    //   111: aload 8
    //   113: invokevirtual 159	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   116: astore 6
    //   118: aload 6
    //   120: ifnull +482 -> 602
    //   123: aload 6
    //   125: invokevirtual 164	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   128: astore 12
    //   130: aload 12
    //   132: ldc -90
    //   134: invokevirtual 172	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   137: ifeq +13 -> 150
    //   140: aload 8
    //   142: invokevirtual 159	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   145: astore 6
    //   147: goto -29 -> 118
    //   150: aload 6
    //   152: invokevirtual 173	java/util/zip/ZipEntry:isDirectory	()Z
    //   155: ifne -15 -> 140
    //   158: aload 12
    //   160: bipush 47
    //   162: invokevirtual 177	java/lang/String:indexOf	(I)I
    //   165: iconst_m1
    //   166: if_icmpne -26 -> 140
    //   169: aload 12
    //   171: ldc 8
    //   173: invokevirtual 180	java/lang/String:endsWith	(Ljava/lang/String;)Z
    //   176: ifeq -36 -> 140
    //   179: new 72	java/lang/StringBuilder
    //   182: dup
    //   183: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   186: ldc -74
    //   188: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: aload 12
    //   193: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   199: astore 6
    //   201: aload 10
    //   203: aload 6
    //   205: invokeinterface 188 2 0
    //   210: pop
    //   211: new 38	java/io/File
    //   214: dup
    //   215: aload_0
    //   216: aload 6
    //   218: invokespecial 59	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   221: astore 6
    //   223: aload 9
    //   225: aload 6
    //   227: invokeinterface 191 2 0
    //   232: pop
    //   233: lload_2
    //   234: lconst_0
    //   235: lcmp
    //   236: ifle +103 -> 339
    //   239: aload 6
    //   241: invokevirtual 195	java/io/File:lastModified	()J
    //   244: lload_2
    //   245: lcmp
    //   246: ifle +93 -> 339
    //   249: ldc 64
    //   251: iconst_2
    //   252: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   255: ifeq -115 -> 140
    //   258: ldc 64
    //   260: new 72	java/lang/StringBuilder
    //   263: dup
    //   264: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   267: ldc -59
    //   269: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   272: aload 12
    //   274: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: ldc -57
    //   279: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   285: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   288: pop
    //   289: goto -149 -> 140
    //   292: astore_1
    //   293: ldc 64
    //   295: new 72	java/lang/StringBuilder
    //   298: dup
    //   299: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   302: ldc -55
    //   304: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   307: aload_0
    //   308: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   311: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   314: aload_1
    //   315: invokestatic 205	android/util/Log:wtf	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   318: pop
    //   319: iconst_0
    //   320: anewarray 38	java/io/File
    //   323: astore_0
    //   324: aload 8
    //   326: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   329: aload 7
    //   331: invokevirtual 211	java/io/InputStream:close	()V
    //   334: aload_0
    //   335: areturn
    //   336: astore_1
    //   337: aload_0
    //   338: areturn
    //   339: ldc 64
    //   341: iconst_2
    //   342: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   345: ifeq +39 -> 384
    //   348: ldc 64
    //   350: new 72	java/lang/StringBuilder
    //   353: dup
    //   354: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   357: ldc -43
    //   359: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: aload 12
    //   364: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: ldc -41
    //   369: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   372: aload 6
    //   374: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   377: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   380: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   383: pop
    //   384: aload 6
    //   386: invokevirtual 219	java/io/File:getParentFile	()Ljava/io/File;
    //   389: astore 12
    //   391: aload 12
    //   393: ifnull +65 -> 458
    //   396: aload 12
    //   398: invokevirtual 222	java/io/File:exists	()Z
    //   401: ifne +57 -> 458
    //   404: aload 12
    //   406: invokevirtual 225	java/io/File:mkdirs	()Z
    //   409: ifne +49 -> 458
    //   412: ldc 64
    //   414: new 72	java/lang/StringBuilder
    //   417: dup
    //   418: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   421: ldc -29
    //   423: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   426: aload 6
    //   428: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   431: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   434: invokestatic 229	android/util/Log:wtf	(Ljava/lang/String;Ljava/lang/String;)I
    //   437: pop
    //   438: iconst_0
    //   439: anewarray 38	java/io/File
    //   442: astore_1
    //   443: aload 8
    //   445: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   448: aload 7
    //   450: invokevirtual 211	java/io/InputStream:close	()V
    //   453: aload_1
    //   454: areturn
    //   455: astore_0
    //   456: aload_1
    //   457: areturn
    //   458: new 231	java/io/BufferedOutputStream
    //   461: dup
    //   462: new 233	java/io/FileOutputStream
    //   465: dup
    //   466: aload 6
    //   468: invokespecial 235	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   471: invokespecial 238	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   474: astore 12
    //   476: aload 8
    //   478: aload 11
    //   480: invokevirtual 242	java/util/zip/ZipInputStream:read	([B)I
    //   483: istore 4
    //   485: iload 4
    //   487: iconst_m1
    //   488: if_icmpeq +40 -> 528
    //   491: aload 12
    //   493: aload 11
    //   495: iconst_0
    //   496: iload 4
    //   498: invokevirtual 248	java/io/OutputStream:write	([BII)V
    //   501: goto -25 -> 476
    //   504: astore_1
    //   505: aload 12
    //   507: invokevirtual 249	java/io/OutputStream:close	()V
    //   510: aload_1
    //   511: athrow
    //   512: astore_0
    //   513: aload 8
    //   515: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   518: aload_0
    //   519: athrow
    //   520: astore_0
    //   521: aload 7
    //   523: invokevirtual 211	java/io/InputStream:close	()V
    //   526: aload_0
    //   527: athrow
    //   528: aload 12
    //   530: invokevirtual 249	java/io/OutputStream:close	()V
    //   533: ldc 64
    //   535: iconst_2
    //   536: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   539: ifeq -399 -> 140
    //   542: ldc 64
    //   544: new 72	java/lang/StringBuilder
    //   547: dup
    //   548: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   551: ldc -5
    //   553: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   556: invokestatic 256	java/lang/System:currentTimeMillis	()J
    //   559: invokevirtual 259	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   562: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   565: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   568: pop
    //   569: ldc 64
    //   571: new 72	java/lang/StringBuilder
    //   574: dup
    //   575: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   578: ldc_w 261
    //   581: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   584: aload 6
    //   586: invokevirtual 195	java/io/File:lastModified	()J
    //   589: invokevirtual 259	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   592: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   595: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   598: pop
    //   599: goto -459 -> 140
    //   602: aload_1
    //   603: ifnull +121 -> 724
    //   606: aload_1
    //   607: arraylength
    //   608: istore 5
    //   610: iconst_0
    //   611: istore 4
    //   613: iload 4
    //   615: iload 5
    //   617: if_icmpge +107 -> 724
    //   620: aload_1
    //   621: iload 4
    //   623: aaload
    //   624: astore 6
    //   626: aload 10
    //   628: aload 6
    //   630: invokevirtual 262	java/io/File:getName	()Ljava/lang/String;
    //   633: invokeinterface 265 2 0
    //   638: ifne +142 -> 780
    //   641: ldc 64
    //   643: iconst_2
    //   644: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   647: ifeq +30 -> 677
    //   650: ldc 64
    //   652: new 72	java/lang/StringBuilder
    //   655: dup
    //   656: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   659: ldc_w 267
    //   662: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   665: aload 6
    //   667: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   670: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   673: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   676: pop
    //   677: aload 6
    //   679: invokevirtual 110	java/io/File:delete	()Z
    //   682: ifne +98 -> 780
    //   685: ldc 64
    //   687: iconst_2
    //   688: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   691: ifeq +89 -> 780
    //   694: ldc 64
    //   696: new 72	java/lang/StringBuilder
    //   699: dup
    //   700: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   703: ldc_w 269
    //   706: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   709: aload 6
    //   711: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   714: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   717: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   720: pop
    //   721: goto +59 -> 780
    //   724: aload 9
    //   726: aload 9
    //   728: invokeinterface 273 1 0
    //   733: anewarray 38	java/io/File
    //   736: invokeinterface 277 2 0
    //   741: checkcast 279	[Ljava/io/File;
    //   744: astore_1
    //   745: aload 8
    //   747: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   750: aload 7
    //   752: invokevirtual 211	java/io/InputStream:close	()V
    //   755: aload_1
    //   756: areturn
    //   757: astore_0
    //   758: aload_1
    //   759: areturn
    //   760: astore_0
    //   761: goto -313 -> 448
    //   764: astore_0
    //   765: goto -15 -> 750
    //   768: astore_1
    //   769: goto -440 -> 329
    //   772: astore_1
    //   773: goto -255 -> 518
    //   776: astore_1
    //   777: goto -251 -> 526
    //   780: iload 4
    //   782: iconst_1
    //   783: iadd
    //   784: istore 4
    //   786: goto -173 -> 613
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	789	0	paramFile	File
    //   0	789	1	paramArrayOfFile	File[]
    //   0	789	2	paramLong	long
    //   483	302	4	i	int
    //   608	10	5	j	int
    //   116	594	6	localObject1	Object
    //   41	710	7	localInputStream	java.io.InputStream
    //   102	644	8	localZipInputStream	java.util.zip.ZipInputStream
    //   80	647	9	localArrayList	ArrayList
    //   91	536	10	localHashSet	java.util.HashSet
    //   109	385	11	arrayOfByte	byte[]
    //   128	401	12	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   104	118	292	java/io/IOException
    //   123	140	292	java/io/IOException
    //   140	147	292	java/io/IOException
    //   150	233	292	java/io/IOException
    //   239	289	292	java/io/IOException
    //   339	384	292	java/io/IOException
    //   384	391	292	java/io/IOException
    //   396	443	292	java/io/IOException
    //   458	476	292	java/io/IOException
    //   505	512	292	java/io/IOException
    //   528	599	292	java/io/IOException
    //   606	610	292	java/io/IOException
    //   626	677	292	java/io/IOException
    //   677	721	292	java/io/IOException
    //   724	745	292	java/io/IOException
    //   329	334	336	java/io/IOException
    //   448	453	455	java/io/IOException
    //   476	485	504	finally
    //   491	501	504	finally
    //   104	118	512	finally
    //   123	140	512	finally
    //   140	147	512	finally
    //   150	233	512	finally
    //   239	289	512	finally
    //   293	324	512	finally
    //   339	384	512	finally
    //   384	391	512	finally
    //   396	443	512	finally
    //   458	476	512	finally
    //   505	512	512	finally
    //   528	599	512	finally
    //   606	610	512	finally
    //   626	677	512	finally
    //   677	721	512	finally
    //   724	745	512	finally
    //   93	104	520	finally
    //   324	329	520	finally
    //   443	448	520	finally
    //   513	518	520	finally
    //   518	520	520	finally
    //   745	750	520	finally
    //   750	755	757	java/io/IOException
    //   443	448	760	java/io/IOException
    //   745	750	764	java/io/IOException
    //   324	329	768	java/io/IOException
    //   513	518	772	java/io/IOException
    //   521	526	776	java/io/IOException
  }
  
  /* Error */
  public static boolean extractZip(File paramFile, java.io.InputStream paramInputStream)
  {
    // Byte code:
    //   0: new 152	java/util/zip/ZipInputStream
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 155	java/util/zip/ZipInputStream:<init>	(Ljava/io/InputStream;)V
    //   8: astore_3
    //   9: sipush 2000
    //   12: newarray <illegal type>
    //   14: astore 4
    //   16: aload_3
    //   17: invokevirtual 159	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   20: astore_1
    //   21: aload_1
    //   22: ifnull +202 -> 224
    //   25: aload_1
    //   26: invokevirtual 164	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   29: astore 5
    //   31: aload 5
    //   33: ldc -90
    //   35: invokevirtual 172	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   38: ifeq +11 -> 49
    //   41: aload_3
    //   42: invokevirtual 159	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   45: astore_1
    //   46: goto -25 -> 21
    //   49: aload_1
    //   50: invokevirtual 173	java/util/zip/ZipEntry:isDirectory	()Z
    //   53: ifne -12 -> 41
    //   56: new 38	java/io/File
    //   59: dup
    //   60: aload_0
    //   61: aload 5
    //   63: invokespecial 59	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   66: astore_1
    //   67: aload_1
    //   68: invokevirtual 219	java/io/File:getParentFile	()Ljava/io/File;
    //   71: astore 5
    //   73: aload 5
    //   75: ifnull +50 -> 125
    //   78: aload 5
    //   80: invokevirtual 222	java/io/File:exists	()Z
    //   83: ifne +42 -> 125
    //   86: aload 5
    //   88: invokevirtual 225	java/io/File:mkdirs	()Z
    //   91: ifne +34 -> 125
    //   94: ldc 64
    //   96: new 72	java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   103: ldc -29
    //   105: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: aload_1
    //   109: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   112: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   115: invokestatic 115	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   118: pop
    //   119: aload_3
    //   120: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   123: iconst_0
    //   124: ireturn
    //   125: new 231	java/io/BufferedOutputStream
    //   128: dup
    //   129: new 233	java/io/FileOutputStream
    //   132: dup
    //   133: aload_1
    //   134: invokespecial 235	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   137: invokespecial 238	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   140: astore_1
    //   141: aload_3
    //   142: aload 4
    //   144: invokevirtual 242	java/util/zip/ZipInputStream:read	([B)I
    //   147: istore_2
    //   148: iload_2
    //   149: iconst_m1
    //   150: if_icmpeq +60 -> 210
    //   153: aload_1
    //   154: aload 4
    //   156: iconst_0
    //   157: iload_2
    //   158: invokevirtual 248	java/io/OutputStream:write	([BII)V
    //   161: goto -20 -> 141
    //   164: astore 4
    //   166: aload_1
    //   167: invokevirtual 249	java/io/OutputStream:close	()V
    //   170: aload 4
    //   172: athrow
    //   173: astore_1
    //   174: ldc 64
    //   176: new 72	java/lang/StringBuilder
    //   179: dup
    //   180: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   183: ldc_w 283
    //   186: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: aload_0
    //   190: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   193: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   196: aload_1
    //   197: invokestatic 285	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   200: pop
    //   201: aload_3
    //   202: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   205: iconst_0
    //   206: ireturn
    //   207: astore_0
    //   208: iconst_0
    //   209: ireturn
    //   210: aload_1
    //   211: invokevirtual 249	java/io/OutputStream:close	()V
    //   214: goto -173 -> 41
    //   217: astore_0
    //   218: aload_3
    //   219: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   222: aload_0
    //   223: athrow
    //   224: aload_3
    //   225: invokevirtual 208	java/util/zip/ZipInputStream:close	()V
    //   228: iconst_1
    //   229: ireturn
    //   230: astore_0
    //   231: iconst_1
    //   232: ireturn
    //   233: astore_0
    //   234: iconst_0
    //   235: ireturn
    //   236: astore_1
    //   237: goto -15 -> 222
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	240	0	paramFile	File
    //   0	240	1	paramInputStream	java.io.InputStream
    //   147	11	2	i	int
    //   8	217	3	localZipInputStream	java.util.zip.ZipInputStream
    //   14	141	4	arrayOfByte	byte[]
    //   164	7	4	localObject1	Object
    //   29	58	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   141	148	164	finally
    //   153	161	164	finally
    //   9	21	173	java/io/IOException
    //   25	41	173	java/io/IOException
    //   41	46	173	java/io/IOException
    //   49	73	173	java/io/IOException
    //   78	119	173	java/io/IOException
    //   125	141	173	java/io/IOException
    //   166	173	173	java/io/IOException
    //   210	214	173	java/io/IOException
    //   201	205	207	java/io/IOException
    //   9	21	217	finally
    //   25	41	217	finally
    //   41	46	217	finally
    //   49	73	217	finally
    //   78	119	217	finally
    //   125	141	217	finally
    //   166	173	217	finally
    //   174	201	217	finally
    //   210	214	217	finally
    //   224	228	230	java/io/IOException
    //   119	123	233	java/io/IOException
    //   218	222	236	java/io/IOException
  }
  
  public static boolean extractZip(File paramFile, byte[] paramArrayOfByte)
  {
    return extractZip(paramFile, new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public static void finishUpdate(boolean paramBoolean)
  {
    if (paramBoolean) {
      swapFolders();
    }
  }
  
  /* Error */
  public static byte[] getCheckSum(File paramFile)
  {
    // Byte code:
    //   0: ldc_w 303
    //   3: invokestatic 309	java/security/MessageDigest:getInstance	(Ljava/lang/String;)Ljava/security/MessageDigest;
    //   6: astore_3
    //   7: sipush 4096
    //   10: newarray <illegal type>
    //   12: astore 4
    //   14: new 311	java/io/BufferedInputStream
    //   17: dup
    //   18: new 313	java/io/FileInputStream
    //   21: dup
    //   22: aload_0
    //   23: invokespecial 314	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   26: invokespecial 315	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   29: astore_2
    //   30: aload_2
    //   31: aload 4
    //   33: invokevirtual 316	java/io/BufferedInputStream:read	([B)I
    //   36: istore_1
    //   37: iload_1
    //   38: iconst_m1
    //   39: if_icmpne +14 -> 53
    //   42: aload_3
    //   43: invokevirtual 320	java/security/MessageDigest:digest	()[B
    //   46: astore_3
    //   47: aload_2
    //   48: invokevirtual 321	java/io/BufferedInputStream:close	()V
    //   51: aload_3
    //   52: areturn
    //   53: aload_3
    //   54: aload 4
    //   56: iconst_0
    //   57: iload_1
    //   58: invokevirtual 324	java/security/MessageDigest:update	([BII)V
    //   61: goto -31 -> 30
    //   64: astore_3
    //   65: aload_2
    //   66: invokevirtual 321	java/io/BufferedInputStream:close	()V
    //   69: aload_3
    //   70: athrow
    //   71: astore_0
    //   72: ldc 64
    //   74: bipush 6
    //   76: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   79: ifeq +13 -> 92
    //   82: ldc 64
    //   84: ldc_w 326
    //   87: aload_0
    //   88: invokestatic 285	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   91: pop
    //   92: aconst_null
    //   93: areturn
    //   94: astore_2
    //   95: ldc 64
    //   97: bipush 6
    //   99: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   102: ifeq -10 -> 92
    //   105: ldc 64
    //   107: new 72	java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   114: ldc_w 328
    //   117: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: aload_0
    //   121: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   124: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   127: aload_2
    //   128: invokestatic 285	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   131: pop
    //   132: goto -40 -> 92
    //   135: astore_0
    //   136: ldc 64
    //   138: bipush 6
    //   140: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   143: ifeq -51 -> 92
    //   146: ldc 64
    //   148: ldc_w 330
    //   151: aload_0
    //   152: invokestatic 285	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   155: pop
    //   156: goto -64 -> 92
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	159	0	paramFile	File
    //   36	22	1	i	int
    //   29	37	2	localBufferedInputStream	java.io.BufferedInputStream
    //   94	34	2	localIOException	IOException
    //   6	48	3	localObject1	Object
    //   64	6	3	localObject2	Object
    //   12	43	4	arrayOfByte	byte[]
    // Exception table:
    //   from	to	target	type
    //   30	37	64	finally
    //   42	47	64	finally
    //   53	61	64	finally
    //   0	30	71	java/security/NoSuchAlgorithmException
    //   47	51	71	java/security/NoSuchAlgorithmException
    //   65	71	71	java/security/NoSuchAlgorithmException
    //   0	30	94	java/io/IOException
    //   47	51	94	java/io/IOException
    //   65	71	94	java/io/IOException
    //   0	30	135	java/lang/Throwable
    //   47	51	135	java/lang/Throwable
    //   65	71	135	java/lang/Throwable
  }
  
  public static byte[] getCheckSum(String paramString)
  {
    if (paramString.equals("resources.ap_"))
    {
      paramString = getExternalResourceFile();
      if (paramString != null) {
        return getCheckSum(paramString);
      }
    }
    return null;
  }
  
  private static File getDataFolder()
  {
    return new File(Paths.getDataDirectory(AppInfo.applicationId));
  }
  
  private static File getDexFileFolder(File paramFile, boolean paramBoolean)
  {
    File localFile = new File(paramFile, "dex");
    paramFile = localFile;
    if (paramBoolean)
    {
      paramFile = localFile;
      if (!localFile.isDirectory())
      {
        paramFile = localFile;
        if (!localFile.mkdirs())
        {
          Log.e("InstantRun", "Failed to create directory " + localFile);
          paramFile = null;
        }
      }
    }
    return paramFile;
  }
  
  public static List<String> getDexList(Context paramContext, long paramLong)
  {
    File localFile2 = getDataFolder();
    long l4 = getMostRecentTempDexTime(localFile2);
    File localFile1 = getDexFileFolder(localFile2, false);
    int i = 0;
    File[] arrayOfFile1;
    if ((localFile1 == null) || (!localFile1.isDirectory()))
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "No local dex slice folder: First run since installation.");
      }
      localFile1 = getDexFileFolder(localFile2, true);
      if (localFile1 == null)
      {
        Log.wtf("InstantRun", "Couldn't create dex code folder");
        return Collections.emptyList();
      }
      arrayOfFile1 = extractSlices(localFile1, null, -1L);
      if (arrayOfFile1.length > 0) {
        i = 1;
      }
    }
    while ((arrayOfFile1 == null) || (arrayOfFile1.length == 0))
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Cannot find dex classes, not patching them in");
      }
      return Collections.emptyList();
      i = 0;
      continue;
      arrayOfFile1 = localFile1.listFiles();
    }
    long l1 = paramLong;
    int j;
    long l3;
    File[] arrayOfFile2;
    if ((i == 0) && (arrayOfFile1.length > 0))
    {
      long l2 = paramLong;
      j = arrayOfFile1.length;
      i = 0;
      while (i < j)
      {
        l3 = arrayOfFile1[i].lastModified();
        l2 = Math.min(l3, l2);
        l1 = Math.max(l3, l1);
        i += 1;
      }
      arrayOfFile2 = arrayOfFile1;
      l3 = l1;
      if (l2 < paramLong)
      {
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "One or more slices were older than APK: extracting newer slices");
        }
        arrayOfFile2 = extractSlices(localFile1, arrayOfFile1, paramLong);
        l3 = l1;
      }
    }
    for (;;)
    {
      if (l4 > l3)
      {
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Your app does not have the latest code changes because it was restarted manually. Please run from IDE instead.");
        }
        Restarter.showToastWhenPossible(paramContext, "Your app does not have the latest code changes because it was restarted manually. Please run from IDE instead.");
      }
      paramContext = new ArrayList(arrayOfFile2.length);
      j = arrayOfFile2.length;
      i = 0;
      while (i < j)
      {
        arrayOfFile1 = arrayOfFile2[i];
        if (arrayOfFile1.getName().endsWith(".dex")) {
          paramContext.add(arrayOfFile1.getPath());
        }
        i += 1;
      }
      arrayOfFile2 = arrayOfFile1;
      l3 = l1;
      if (l4 > 0L)
      {
        purgeTempDexFiles(localFile2);
        arrayOfFile2 = arrayOfFile1;
        l3 = l1;
      }
    }
    Collections.sort(paramContext, Collections.reverseOrder());
    return paramContext;
  }
  
  public static File getExternalResourceFile()
  {
    File localFile2 = getResourceFile(getReadFolder());
    File localFile1 = localFile2;
    if (!localFile2.exists())
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Cannot find external resources, not patching them in");
      }
      localFile1 = null;
    }
    return localFile1;
  }
  
  public static long getFileSize(String paramString)
  {
    if (paramString.equals("resources.ap_"))
    {
      paramString = getExternalResourceFile();
      if (paramString != null) {
        return paramString.length();
      }
    }
    return -1L;
  }
  
  public static long getMostRecentTempDexTime(File paramFile)
  {
    long l2 = 0L;
    paramFile = getTempDexFileFolder(paramFile);
    if (!paramFile.isDirectory()) {}
    do
    {
      return l2;
      paramFile = paramFile.listFiles();
    } while (paramFile == null);
    long l1 = 0L;
    int j = paramFile.length;
    int i = 0;
    for (;;)
    {
      l2 = l1;
      if (i >= j) {
        break;
      }
      Object localObject = paramFile[i];
      l2 = l1;
      if (((File)localObject).getPath().endsWith(".dex")) {
        l2 = Math.max(l1, ((File)localObject).lastModified());
      }
      i += 1;
      l1 = l2;
    }
  }
  
  public static File getNativeLibraryFolder()
  {
    return new File(Paths.getMainApkDataDirectory(AppInfo.applicationId), "lib");
  }
  
  public static File getReadFolder()
  {
    if (leftIsActive()) {}
    for (String str = "left";; str = "right") {
      return new File(getDataFolder(), str);
    }
  }
  
  private static File getResourceFile(File paramFile)
  {
    return new File(paramFile, "resources.ap_");
  }
  
  public static File getTempDexFile()
  {
    Object localObject2 = getDataFolder();
    Object localObject1 = getTempDexFileFolder((File)localObject2);
    if (!((File)localObject1).exists()) {
      if (!((File)localObject1).mkdirs())
      {
        Log.e("InstantRun", "Failed to create directory " + localObject1);
        localObject1 = null;
      }
    }
    do
    {
      return (File)localObject1;
      sHavePurgedTempDexFolder = true;
      for (;;)
      {
        localObject2 = ((File)localObject1).listFiles();
        i = -1;
        k = i;
        if (localObject2 == null) {
          break;
        }
        int n = localObject2.length;
        int j = 0;
        for (;;)
        {
          k = i;
          if (j >= n) {
            break;
          }
          String str = localObject2[j].getName();
          k = i;
          if (str.startsWith("reload"))
          {
            k = i;
            if (str.endsWith(".dex")) {
              str = str.substring("reload".length(), str.length() - ".dex".length());
            }
          }
          try
          {
            int m = Integer.decode(str).intValue();
            k = i;
            if (m > i) {
              k = m;
            }
          }
          catch (NumberFormatException localNumberFormatException)
          {
            for (;;)
            {
              k = i;
            }
          }
          j += 1;
          i = k;
        }
        if (!sHavePurgedTempDexFolder) {
          purgeTempDexFiles((File)localObject2);
        }
      }
      localObject2 = new File((File)localObject1, String.format("%s0x%04x%s", new Object[] { "reload", Integer.valueOf(k + 1), ".dex" }));
      localObject1 = localObject2;
    } while (!Log.isLoggable("InstantRun", 2));
    Log.v("InstantRun", "Writing new dex file: " + localObject2);
    return (File)localObject2;
  }
  
  private static File getTempDexFileFolder(File paramFile)
  {
    return new File(paramFile, "dex-temp");
  }
  
  public static File getWriteFolder(boolean paramBoolean)
  {
    if (leftIsActive()) {}
    for (Object localObject = "right";; localObject = "left")
    {
      localObject = new File(getDataFolder(), (String)localObject);
      if ((paramBoolean) && (((File)localObject).exists()))
      {
        delete((File)localObject);
        if (!((File)localObject).mkdirs()) {
          Log.e("InstantRun", "Failed to create folder " + localObject);
        }
      }
      return (File)localObject;
    }
  }
  
  private static boolean leftIsActive()
  {
    Object localObject1 = new File(getDataFolder(), "active");
    if (!((File)localObject1).exists()) {
      return true;
    }
    try
    {
      localObject1 = new BufferedReader(new FileReader((File)localObject1));
      try
      {
        boolean bool = "left".equals(((BufferedReader)localObject1).readLine());
        return bool;
      }
      finally
      {
        ((BufferedReader)localObject1).close();
      }
      return true;
    }
    catch (IOException localIOException) {}
  }
  
  public static void purgeTempDexFiles(File paramFile)
  {
    sHavePurgedTempDexFolder = true;
    paramFile = getTempDexFileFolder(paramFile);
    if (!paramFile.isDirectory()) {}
    for (;;)
    {
      return;
      paramFile = paramFile.listFiles();
      if (paramFile != null)
      {
        int j = paramFile.length;
        int i = 0;
        while (i < j)
        {
          Object localObject = paramFile[i];
          if ((((File)localObject).getPath().endsWith(".dex")) && (!((File)localObject).delete())) {
            Log.e("InstantRun", "Could not delete temp dex file " + localObject);
          }
          i += 1;
        }
      }
    }
  }
  
  /* Error */
  public static byte[] readRawBytes(File paramFile)
  {
    // Byte code:
    //   0: ldc 64
    //   2: iconst_2
    //   3: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   6: ifeq +29 -> 35
    //   9: ldc 64
    //   11: new 72	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   18: ldc_w 491
    //   21: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_0
    //   25: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   28: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   31: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   34: pop
    //   35: aload_0
    //   36: invokevirtual 422	java/io/File:length	()J
    //   39: lstore 4
    //   41: lload 4
    //   43: ldc2_w 492
    //   46: lcmp
    //   47: ifle +47 -> 94
    //   50: ldc 64
    //   52: iconst_2
    //   53: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   56: ifeq +242 -> 298
    //   59: ldc 64
    //   61: new 72	java/lang/StringBuilder
    //   64: dup
    //   65: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   68: ldc_w 495
    //   71: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: lload 4
    //   76: invokevirtual 259	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   79: ldc 84
    //   81: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   87: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   90: pop
    //   91: goto +207 -> 298
    //   94: lload 4
    //   96: l2i
    //   97: newarray <illegal type>
    //   99: astore 7
    //   101: new 311	java/io/BufferedInputStream
    //   104: dup
    //   105: new 313	java/io/FileInputStream
    //   108: dup
    //   109: aload_0
    //   110: invokespecial 314	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   113: invokespecial 315	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   116: astore 6
    //   118: iconst_0
    //   119: istore_2
    //   120: aload 7
    //   122: arraylength
    //   123: iconst_0
    //   124: isub
    //   125: istore_1
    //   126: iload_1
    //   127: ifle +18 -> 145
    //   130: aload 6
    //   132: aload 7
    //   134: iload_2
    //   135: iload_1
    //   136: invokevirtual 498	java/io/BufferedInputStream:read	([BII)I
    //   139: istore_3
    //   140: iload_3
    //   141: iconst_m1
    //   142: if_icmpne +135 -> 277
    //   145: ldc 64
    //   147: iconst_2
    //   148: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   151: ifeq +41 -> 192
    //   154: ldc 64
    //   156: new 72	java/lang/StringBuilder
    //   159: dup
    //   160: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   163: ldc_w 500
    //   166: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: aload 7
    //   171: arraylength
    //   172: invokevirtual 503	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   175: ldc_w 505
    //   178: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload_0
    //   182: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   185: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   188: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   191: pop
    //   192: aload 6
    //   194: invokevirtual 321	java/io/BufferedInputStream:close	()V
    //   197: aload 7
    //   199: areturn
    //   200: astore 6
    //   202: ldc 64
    //   204: bipush 6
    //   206: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   209: ifeq +31 -> 240
    //   212: ldc 64
    //   214: new 72	java/lang/StringBuilder
    //   217: dup
    //   218: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   221: ldc_w 328
    //   224: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: aload_0
    //   228: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   231: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   234: aload 6
    //   236: invokestatic 285	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   239: pop
    //   240: ldc 64
    //   242: iconst_2
    //   243: invokestatic 70	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   246: ifeq +29 -> 275
    //   249: ldc 64
    //   251: new 72	java/lang/StringBuilder
    //   254: dup
    //   255: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   258: ldc_w 507
    //   261: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: aload_0
    //   265: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   268: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   271: invokestatic 92	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   274: pop
    //   275: aconst_null
    //   276: areturn
    //   277: iload_2
    //   278: iload_3
    //   279: iadd
    //   280: istore_2
    //   281: iload_1
    //   282: iload_3
    //   283: isub
    //   284: istore_1
    //   285: goto -159 -> 126
    //   288: astore 7
    //   290: aload 6
    //   292: invokevirtual 321	java/io/BufferedInputStream:close	()V
    //   295: aload 7
    //   297: athrow
    //   298: aconst_null
    //   299: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	300	0	paramFile	File
    //   125	160	1	i	int
    //   119	162	2	j	int
    //   139	145	3	k	int
    //   39	56	4	l	long
    //   116	77	6	localBufferedInputStream	java.io.BufferedInputStream
    //   200	91	6	localIOException	IOException
    //   99	99	7	arrayOfByte	byte[]
    //   288	8	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	35	200	java/io/IOException
    //   35	41	200	java/io/IOException
    //   50	91	200	java/io/IOException
    //   94	118	200	java/io/IOException
    //   192	197	200	java/io/IOException
    //   290	298	200	java/io/IOException
    //   120	126	288	finally
    //   130	140	288	finally
    //   145	192	288	finally
  }
  
  /* Error */
  private static void setLeftActive(boolean paramBoolean)
  {
    // Byte code:
    //   0: invokestatic 351	com/android/tools/fd/runtime/FileManager:getDataFolder	()Ljava/io/File;
    //   3: astore_1
    //   4: new 38	java/io/File
    //   7: dup
    //   8: aload_1
    //   9: ldc 11
    //   11: invokespecial 59	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   14: astore_2
    //   15: aload_2
    //   16: invokevirtual 222	java/io/File:exists	()Z
    //   19: ifeq +78 -> 97
    //   22: aload_2
    //   23: invokevirtual 110	java/io/File:delete	()Z
    //   26: ifne +28 -> 54
    //   29: ldc 64
    //   31: new 72	java/lang/StringBuilder
    //   34: dup
    //   35: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   38: ldc 124
    //   40: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: aload_2
    //   44: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   47: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   50: invokestatic 115	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   53: pop
    //   54: new 510	java/io/BufferedWriter
    //   57: dup
    //   58: new 512	java/io/OutputStreamWriter
    //   61: dup
    //   62: new 233	java/io/FileOutputStream
    //   65: dup
    //   66: aload_2
    //   67: invokespecial 235	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   70: ldc_w 514
    //   73: invokespecial 517	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
    //   76: invokespecial 520	java/io/BufferedWriter:<init>	(Ljava/io/Writer;)V
    //   79: astore_2
    //   80: iload_0
    //   81: ifeq +56 -> 137
    //   84: ldc 14
    //   86: astore_1
    //   87: aload_2
    //   88: aload_1
    //   89: invokevirtual 524	java/io/Writer:write	(Ljava/lang/String;)V
    //   92: aload_2
    //   93: invokevirtual 525	java/io/Writer:close	()V
    //   96: return
    //   97: aload_1
    //   98: invokevirtual 222	java/io/File:exists	()Z
    //   101: ifne -47 -> 54
    //   104: aload_1
    //   105: invokevirtual 225	java/io/File:mkdirs	()Z
    //   108: ifne -12 -> 96
    //   111: ldc 64
    //   113: new 72	java/lang/StringBuilder
    //   116: dup
    //   117: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   120: ldc -29
    //   122: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: aload_1
    //   126: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   129: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: invokestatic 115	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   135: pop
    //   136: return
    //   137: ldc 17
    //   139: astore_1
    //   140: goto -53 -> 87
    //   143: astore_1
    //   144: aload_2
    //   145: invokevirtual 525	java/io/Writer:close	()V
    //   148: aload_1
    //   149: athrow
    //   150: astore_1
    //   151: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	152	0	paramBoolean	boolean
    //   3	137	1	localObject1	Object
    //   143	6	1	localObject2	Object
    //   150	1	1	localIOException	IOException
    //   14	131	2	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   87	92	143	finally
    //   54	80	150	java/io/IOException
    //   92	96	150	java/io/IOException
    //   144	150	150	java/io/IOException
  }
  
  public static void startUpdate()
  {
    getWriteFolder(true);
  }
  
  public static void swapFolders()
  {
    if (!leftIsActive()) {}
    for (boolean bool = true;; bool = false)
    {
      setLeftActive(bool);
      return;
    }
  }
  
  public static void writeAaptResources(String paramString, byte[] paramArrayOfByte)
  {
    File localFile1 = getResourceFile(getWriteFolder(false));
    File localFile2 = localFile1.getParentFile();
    if ((!localFile2.isDirectory()) && (!localFile2.mkdirs()))
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Cannot create local resource file directory " + localFile2);
      }
      return;
    }
    if (paramString.equals("resources.ap_"))
    {
      writeRawBytes(localFile1, paramArrayOfByte);
      return;
    }
    writeRawBytes(localFile1, paramArrayOfByte);
  }
  
  public static File writeDexShard(byte[] paramArrayOfByte, String paramString)
  {
    File localFile = getDexFileFolder(getDataFolder(), true);
    if (localFile == null) {
      return null;
    }
    paramString = new File(localFile, paramString);
    writeRawBytes(paramString, paramArrayOfByte);
    return paramString;
  }
  
  /* Error */
  public static boolean writeRawBytes(File paramFile, byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: new 231	java/io/BufferedOutputStream
    //   3: dup
    //   4: new 233	java/io/FileOutputStream
    //   7: dup
    //   8: aload_0
    //   9: invokespecial 235	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   12: invokespecial 238	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   15: astore_2
    //   16: aload_2
    //   17: aload_1
    //   18: invokevirtual 538	java/io/BufferedOutputStream:write	([B)V
    //   21: aload_2
    //   22: invokevirtual 541	java/io/BufferedOutputStream:flush	()V
    //   25: aload_2
    //   26: invokevirtual 542	java/io/BufferedOutputStream:close	()V
    //   29: iconst_1
    //   30: ireturn
    //   31: astore_1
    //   32: aload_2
    //   33: invokevirtual 542	java/io/BufferedOutputStream:close	()V
    //   36: aload_1
    //   37: athrow
    //   38: astore_1
    //   39: ldc 64
    //   41: new 72	java/lang/StringBuilder
    //   44: dup
    //   45: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   48: ldc_w 544
    //   51: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: aload_0
    //   55: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   58: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   61: aload_1
    //   62: invokestatic 205	android/util/Log:wtf	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   65: pop
    //   66: new 546	java/lang/RuntimeException
    //   69: dup
    //   70: ldc_w 548
    //   73: iconst_1
    //   74: anewarray 4	java/lang/Object
    //   77: dup
    //   78: iconst_0
    //   79: aload_0
    //   80: aastore
    //   81: invokestatic 467	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   84: invokespecial 549	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   87: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	88	0	paramFile	File
    //   0	88	1	paramArrayOfByte	byte[]
    //   15	18	2	localBufferedOutputStream	java.io.BufferedOutputStream
    // Exception table:
    //   from	to	target	type
    //   16	25	31	finally
    //   0	16	38	java/io/IOException
    //   25	29	38	java/io/IOException
    //   32	38	38	java/io/IOException
  }
  
  public static String writeTempDexFile(byte[] paramArrayOfByte)
  {
    File localFile = getTempDexFile();
    if (localFile != null)
    {
      writeRawBytes(localFile, paramArrayOfByte);
      return localFile.getPath();
    }
    Log.e("InstantRun", "No file to write temp dex content to");
    return null;
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\FileManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */