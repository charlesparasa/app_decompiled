package com.android.tools.fd.runtime;

import com.android.tools.fd.common.Log;
import com.android.tools.fd.common.Log.Logging;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AndroidInstantRuntime
{
  private static Field getField(Class paramClass, String paramString)
  {
    paramClass = getFieldByName(paramClass, paramString);
    if (paramClass == null) {
      throw new RuntimeException(new NoSuchElementException(paramString));
    }
    paramClass.setAccessible(true);
    return paramClass;
  }
  
  private static Field getFieldByName(Class<?> paramClass, String paramString)
  {
    if ((Log.logging != null) && (Log.logging.isLoggable(Level.FINE))) {
      Log.logging.log(Level.FINE, String.format("getFieldByName:%s in %s", new Object[] { paramString, paramClass.getName() }));
    }
    while (paramClass != null) {
      try
      {
        Field localField = paramClass.getDeclaredField(paramString);
        return localField;
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        paramClass = paramClass.getSuperclass();
      }
    }
    return null;
  }
  
  private static Method getMethodByName(Class<?> paramClass, String paramString, Class[] paramArrayOfClass)
  {
    if (paramClass == null) {}
    for (;;)
    {
      return null;
      while (paramClass != null)
      {
        Class localClass;
        try
        {
          Method localMethod = paramClass.getDeclaredMethod(paramString, paramArrayOfClass);
          return localMethod;
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          localClass = paramClass.getSuperclass();
          paramClass = localClass;
        }
        if (localClass != null)
        {
          paramClass = localClass;
          if (Log.logging != null)
          {
            paramClass = localClass;
            if (Log.logging.isLoggable(Level.FINE))
            {
              Log.logging.log(Level.FINE, String.format("getMethodByName:Looking in %s now", new Object[] { localClass.getName() }));
              paramClass = localClass;
            }
          }
        }
      }
    }
  }
  
  public static Object getPrivateField(Object paramObject, Class paramClass, String paramString)
  {
    try
    {
      paramClass = getField(paramClass, paramString).get(paramObject);
      return paramClass;
    }
    catch (IllegalAccessException paramClass)
    {
      if (Log.logging == null) {
        break label61;
      }
    }
    Log.Logging localLogging = Log.logging;
    Level localLevel = Level.SEVERE;
    if (paramObject == null) {}
    for (paramObject = " static";; paramObject = "")
    {
      localLogging.log(localLevel, String.format("Exception during%1$s getField %2$s", new Object[] { paramObject, paramString }), paramClass);
      label61:
      throw new RuntimeException(paramClass);
    }
  }
  
  public static Object getStaticPrivateField(Class paramClass, String paramString)
  {
    return getPrivateField(null, paramClass, paramString);
  }
  
  public static Object invokeProtectedMethod(Object paramObject, Object[] paramArrayOfObject, Class[] paramArrayOfClass, String paramString)
    throws Throwable
  {
    if ((Log.logging != null) && (Log.logging.isLoggable(Level.FINE))) {
      Log.logging.log(Level.FINE, String.format("protectedMethod:%s on %s", new Object[] { paramString, paramObject }));
    }
    try
    {
      paramArrayOfClass = getMethodByName(paramObject.getClass(), paramString, paramArrayOfClass);
      if (paramArrayOfClass == null) {
        throw new RuntimeException(new NoSuchMethodException(paramString));
      }
    }
    catch (InvocationTargetException paramObject)
    {
      throw ((InvocationTargetException)paramObject).getCause();
      paramArrayOfClass.setAccessible(true);
      paramObject = paramArrayOfClass.invoke(paramObject, paramArrayOfObject);
      return paramObject;
    }
    catch (IllegalAccessException paramObject)
    {
      Log.logging.log(Level.SEVERE, String.format("Exception while invoking %s", new Object[] { paramString }), (Throwable)paramObject);
      throw new RuntimeException((Throwable)paramObject);
    }
  }
  
  public static Object invokeProtectedStaticMethod(Object[] paramArrayOfObject, Class[] paramArrayOfClass, String paramString, Class paramClass)
    throws Throwable
  {
    if ((Log.logging != null) && (Log.logging.isLoggable(Level.FINE))) {
      Log.logging.log(Level.FINE, String.format("protectedStaticMethod:%s on %s", new Object[] { paramString, paramClass.getName() }));
    }
    try
    {
      paramArrayOfClass = getMethodByName(paramClass, paramString, paramArrayOfClass);
      if (paramArrayOfClass == null) {
        throw new RuntimeException(new NoSuchMethodException(paramString + " in class " + paramClass.getName()));
      }
    }
    catch (InvocationTargetException paramArrayOfObject)
    {
      throw paramArrayOfObject.getCause();
      paramArrayOfClass.setAccessible(true);
      paramArrayOfObject = paramArrayOfClass.invoke(null, paramArrayOfObject);
      return paramArrayOfObject;
    }
    catch (IllegalAccessException paramArrayOfObject)
    {
      Log.logging.log(Level.SEVERE, String.format("Exception while invoking %s", new Object[] { paramString }), paramArrayOfObject);
      throw new RuntimeException(paramArrayOfObject);
    }
  }
  
  /* Error */
  public static <T> T newForClass(Object[] paramArrayOfObject, Class[] paramArrayOfClass, Class<T> paramClass)
    throws Throwable
  {
    // Byte code:
    //   0: aload_2
    //   1: aload_1
    //   2: invokevirtual 172	java/lang/Class:getDeclaredConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   5: astore_1
    //   6: aload_1
    //   7: iconst_1
    //   8: invokevirtual 175	java/lang/reflect/Constructor:setAccessible	(Z)V
    //   11: aload_2
    //   12: aload_1
    //   13: aload_0
    //   14: invokevirtual 179	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   17: invokevirtual 182	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   20: astore_0
    //   21: aload_0
    //   22: areturn
    //   23: astore_0
    //   24: getstatic 43	com/android/tools/fd/common/Log:logging	Lcom/android/tools/fd/common/Log$Logging;
    //   27: getstatic 107	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   30: ldc -72
    //   32: aload_0
    //   33: invokeinterface 114 4 0
    //   38: new 21	java/lang/RuntimeException
    //   41: dup
    //   42: aload_0
    //   43: invokespecial 29	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   46: athrow
    //   47: astore_0
    //   48: aload_0
    //   49: invokevirtual 138	java/lang/reflect/InvocationTargetException:getCause	()Ljava/lang/Throwable;
    //   52: athrow
    //   53: astore_0
    //   54: getstatic 43	com/android/tools/fd/common/Log:logging	Lcom/android/tools/fd/common/Log$Logging;
    //   57: getstatic 107	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   60: ldc -70
    //   62: iconst_1
    //   63: anewarray 4	java/lang/Object
    //   66: dup
    //   67: iconst_0
    //   68: aload_2
    //   69: aastore
    //   70: invokestatic 69	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   73: aload_0
    //   74: invokeinterface 114 4 0
    //   79: new 21	java/lang/RuntimeException
    //   82: dup
    //   83: aload_0
    //   84: invokespecial 29	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   87: athrow
    //   88: astore_0
    //   89: getstatic 43	com/android/tools/fd/common/Log:logging	Lcom/android/tools/fd/common/Log$Logging;
    //   92: getstatic 107	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   95: ldc -70
    //   97: iconst_1
    //   98: anewarray 4	java/lang/Object
    //   101: dup
    //   102: iconst_0
    //   103: aload_2
    //   104: aastore
    //   105: invokestatic 69	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   108: aload_0
    //   109: invokeinterface 114 4 0
    //   114: new 21	java/lang/RuntimeException
    //   117: dup
    //   118: aload_0
    //   119: invokespecial 29	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   122: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	123	0	paramArrayOfObject	Object[]
    //   0	123	1	paramArrayOfClass	Class[]
    //   0	123	2	paramClass	Class<T>
    // Exception table:
    //   from	to	target	type
    //   0	6	23	java/lang/NoSuchMethodException
    //   11	21	47	java/lang/reflect/InvocationTargetException
    //   11	21	53	java/lang/InstantiationException
    //   11	21	88	java/lang/IllegalAccessException
  }
  
  public static void setLogger(Logger paramLogger)
  {
    Log.logging = new Log.Logging()
    {
      public boolean isLoggable(Level paramAnonymousLevel)
      {
        return this.val$logger.isLoggable(paramAnonymousLevel);
      }
      
      public void log(Level paramAnonymousLevel, String paramAnonymousString)
      {
        this.val$logger.log(paramAnonymousLevel, paramAnonymousString);
      }
      
      public void log(Level paramAnonymousLevel, String paramAnonymousString, Throwable paramAnonymousThrowable)
      {
        this.val$logger.log(paramAnonymousLevel, paramAnonymousString, paramAnonymousThrowable);
      }
    };
  }
  
  public static void setPrivateField(Object paramObject1, Object paramObject2, Class paramClass, String paramString)
  {
    try
    {
      getField(paramClass, paramString).set(paramObject1, paramObject2);
      return;
    }
    catch (IllegalAccessException paramObject1)
    {
      if (Log.logging != null) {
        Log.logging.log(Level.SEVERE, String.format("Exception during setPrivateField %s", new Object[] { paramString }), (Throwable)paramObject1);
      }
      throw new RuntimeException((Throwable)paramObject1);
    }
  }
  
  public static void setStaticPrivateField(Object paramObject, Class paramClass, String paramString)
  {
    setPrivateField(null, paramObject, paramClass, paramString);
  }
  
  public static void trace(String paramString)
  {
    if (Log.logging != null) {
      Log.logging.log(Level.FINE, paramString);
    }
  }
  
  public static void trace(String paramString1, String paramString2)
  {
    if (Log.logging != null) {
      Log.logging.log(Level.FINE, String.format("%s %s", new Object[] { paramString1, paramString2 }));
    }
  }
  
  public static void trace(String paramString1, String paramString2, String paramString3)
  {
    if (Log.logging != null) {
      Log.logging.log(Level.FINE, String.format("%s %s %s", new Object[] { paramString1, paramString2, paramString3 }));
    }
  }
  
  public static void trace(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (Log.logging != null) {
      Log.logging.log(Level.FINE, String.format("%s %s %s %s", new Object[] { paramString1, paramString2, paramString3, paramString4 }));
    }
  }
  
  protected static abstract interface Logging
  {
    public abstract boolean isLoggable(Level paramLevel);
    
    public abstract void log(Level paramLevel, String paramString);
    
    public abstract void log(Level paramLevel, String paramString, Throwable paramThrowable);
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\AndroidInstantRuntime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */