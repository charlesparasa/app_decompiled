package com.android.tools.fd.runtime;

import android.util.Log;
import dalvik.system.BaseDexClassLoader;
import java.io.File;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;

public class IncrementalClassLoader
  extends ClassLoader
{
  public static final boolean DEBUG_CLASS_LOADING = false;
  private final DelegateClassLoader delegateClassLoader;
  
  public IncrementalClassLoader(ClassLoader paramClassLoader, String paramString1, String paramString2, List<String> paramList)
  {
    super(paramClassLoader.getParent());
    this.delegateClassLoader = createDelegateClassLoader(paramString1, paramString2, paramList, paramClassLoader);
  }
  
  private static DelegateClassLoader createDelegateClassLoader(String paramString1, String paramString2, List<String> paramList, ClassLoader paramClassLoader)
  {
    return new DelegateClassLoader(createDexPath(paramList), new File(paramString2), paramString1, paramClassLoader, null);
  }
  
  private static String createDexPath(List<String> paramList)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 1;
    Iterator localIterator = paramList.iterator();
    if (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (i != 0) {
        i = 0;
      }
      for (;;)
      {
        localStringBuilder.append(str);
        break;
        localStringBuilder.append(File.pathSeparator);
      }
    }
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "Incremental dex path is " + BootstrapApplication.join('\n', paramList));
    }
    return localStringBuilder.toString();
  }
  
  public static ClassLoader inject(ClassLoader paramClassLoader, String paramString1, String paramString2, List<String> paramList)
  {
    paramString1 = new IncrementalClassLoader(paramClassLoader, paramString1, paramString2, paramList);
    setParent(paramClassLoader, paramString1);
    return paramString1;
  }
  
  private static void setParent(ClassLoader paramClassLoader1, ClassLoader paramClassLoader2)
  {
    try
    {
      Field localField = ClassLoader.class.getDeclaredField("parent");
      localField.setAccessible(true);
      localField.set(paramClassLoader1, paramClassLoader2);
      return;
    }
    catch (IllegalArgumentException paramClassLoader1)
    {
      throw new RuntimeException(paramClassLoader1);
    }
    catch (IllegalAccessException paramClassLoader1)
    {
      throw new RuntimeException(paramClassLoader1);
    }
    catch (NoSuchFieldException paramClassLoader1)
    {
      throw new RuntimeException(paramClassLoader1);
    }
  }
  
  public Class<?> findClass(String paramString)
    throws ClassNotFoundException
  {
    try
    {
      paramString = this.delegateClassLoader.findClass(paramString);
      return paramString;
    }
    catch (ClassNotFoundException paramString)
    {
      throw paramString;
    }
  }
  
  private static class DelegateClassLoader
    extends BaseDexClassLoader
  {
    private DelegateClassLoader(String paramString1, File paramFile, String paramString2, ClassLoader paramClassLoader)
    {
      super(paramFile, paramString2, paramClassLoader);
    }
    
    public Class<?> findClass(String paramString)
      throws ClassNotFoundException
    {
      try
      {
        paramString = super.findClass(paramString);
        return paramString;
      }
      catch (ClassNotFoundException paramString)
      {
        throw paramString;
      }
    }
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\IncrementalClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */