package com.android.tools.fd.runtime;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build.VERSION;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class MonkeyPatcher
{
  public static Object getActivityThread(Context paramContext, Class<?> paramClass)
  {
    Object localObject = paramClass;
    if (paramClass == null) {}
    try
    {
      localObject = Class.forName("android.app.ActivityThread");
      paramClass = ((Class)localObject).getMethod("currentActivityThread", new Class[0]);
      paramClass.setAccessible(true);
      localObject = paramClass.invoke(null, new Object[0]);
      paramClass = (Class<?>)localObject;
      if (localObject == null)
      {
        paramClass = (Class<?>)localObject;
        if (paramContext != null)
        {
          paramClass = paramContext.getClass().getField("mLoadedApk");
          paramClass.setAccessible(true);
          paramContext = paramClass.get(paramContext);
          paramClass = paramContext.getClass().getDeclaredField("mActivityThread");
          paramClass.setAccessible(true);
          paramClass = paramClass.get(paramContext);
        }
      }
      return paramClass;
    }
    catch (Throwable paramContext) {}
    return null;
  }
  
  /* Error */
  public static void monkeyPatchApplication(Context paramContext, android.app.Application paramApplication1, android.app.Application paramApplication2, String paramString)
  {
    // Byte code:
    //   0: ldc 15
    //   2: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   5: astore 7
    //   7: aload_0
    //   8: aload 7
    //   10: invokestatic 69	com/android/tools/fd/runtime/MonkeyPatcher:getActivityThread	(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    //   13: astore 8
    //   15: aload 7
    //   17: ldc 71
    //   19: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_0
    //   23: aload_0
    //   24: iconst_1
    //   25: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   28: aload_0
    //   29: aload 8
    //   31: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   34: checkcast 73	android/app/Application
    //   37: astore 6
    //   39: aload_2
    //   40: ifnull +16 -> 56
    //   43: aload 6
    //   45: aload_1
    //   46: if_acmpne +10 -> 56
    //   49: aload_0
    //   50: aload 8
    //   52: aload_2
    //   53: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   56: aload_2
    //   57: ifnull +71 -> 128
    //   60: aload 7
    //   62: ldc 79
    //   64: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   67: astore_0
    //   68: aload_0
    //   69: iconst_1
    //   70: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   73: aload_0
    //   74: aload 8
    //   76: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   79: checkcast 81	java/util/List
    //   82: astore_0
    //   83: iconst_0
    //   84: istore 4
    //   86: iload 4
    //   88: aload_0
    //   89: invokeinterface 85 1 0
    //   94: if_icmpge +34 -> 128
    //   97: aload_0
    //   98: iload 4
    //   100: invokeinterface 88 2 0
    //   105: aload_1
    //   106: if_acmpne +13 -> 119
    //   109: aload_0
    //   110: iload 4
    //   112: aload_2
    //   113: invokeinterface 91 3 0
    //   118: pop
    //   119: iload 4
    //   121: iconst_1
    //   122: iadd
    //   123: istore 4
    //   125: goto -39 -> 86
    //   128: ldc 93
    //   130: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   133: astore_0
    //   134: aload_0
    //   135: ldc 95
    //   137: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   140: astore 9
    //   142: aload 9
    //   144: iconst_1
    //   145: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   148: aload_0
    //   149: ldc 97
    //   151: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   154: astore 10
    //   156: aload 10
    //   158: iconst_1
    //   159: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   162: aconst_null
    //   163: astore_0
    //   164: ldc 73
    //   166: ldc 43
    //   168: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   171: astore 6
    //   173: aload 6
    //   175: astore_0
    //   176: iconst_2
    //   177: anewarray 99	java/lang/String
    //   180: astore 6
    //   182: aload 6
    //   184: iconst_0
    //   185: ldc 101
    //   187: aastore
    //   188: aload 6
    //   190: iconst_1
    //   191: ldc 103
    //   193: aastore
    //   194: aload 6
    //   196: arraylength
    //   197: istore 5
    //   199: iconst_0
    //   200: istore 4
    //   202: iload 4
    //   204: iload 5
    //   206: if_icmpge +163 -> 369
    //   209: aload 7
    //   211: aload 6
    //   213: iload 4
    //   215: aaload
    //   216: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   219: astore 11
    //   221: aload 11
    //   223: iconst_1
    //   224: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   227: aload 11
    //   229: aload 8
    //   231: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   234: checkcast 105	java/util/Map
    //   237: invokeinterface 109 1 0
    //   242: invokeinterface 115 1 0
    //   247: astore 11
    //   249: aload 11
    //   251: invokeinterface 121 1 0
    //   256: ifeq +104 -> 360
    //   259: aload 11
    //   261: invokeinterface 125 1 0
    //   266: checkcast 127	java/util/Map$Entry
    //   269: invokeinterface 130 1 0
    //   274: checkcast 132	java/lang/ref/WeakReference
    //   277: invokevirtual 134	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
    //   280: astore 12
    //   282: aload 12
    //   284: ifnull -35 -> 249
    //   287: aload 9
    //   289: aload 12
    //   291: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   294: aload_1
    //   295: if_acmpne -46 -> 249
    //   298: aload_2
    //   299: ifnull +11 -> 310
    //   302: aload 9
    //   304: aload 12
    //   306: aload_2
    //   307: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   310: aload_3
    //   311: ifnull +11 -> 322
    //   314: aload 10
    //   316: aload 12
    //   318: aload_3
    //   319: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   322: aload_2
    //   323: ifnull -74 -> 249
    //   326: aload_0
    //   327: ifnull -78 -> 249
    //   330: aload_0
    //   331: aload_2
    //   332: aload 12
    //   334: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   337: goto -88 -> 249
    //   340: astore_0
    //   341: new 136	java/lang/IllegalStateException
    //   344: dup
    //   345: aload_0
    //   346: invokespecial 139	java/lang/IllegalStateException:<init>	(Ljava/lang/Throwable;)V
    //   349: athrow
    //   350: astore_0
    //   351: ldc -115
    //   353: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   356: astore_0
    //   357: goto -223 -> 134
    //   360: iload 4
    //   362: iconst_1
    //   363: iadd
    //   364: istore 4
    //   366: goto -164 -> 202
    //   369: return
    //   370: astore 6
    //   372: goto -196 -> 176
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	375	0	paramContext	Context
    //   0	375	1	paramApplication1	android.app.Application
    //   0	375	2	paramApplication2	android.app.Application
    //   0	375	3	paramString	String
    //   84	281	4	i	int
    //   197	10	5	j	int
    //   37	175	6	localObject1	Object
    //   370	1	6	localNoSuchFieldException	NoSuchFieldException
    //   5	205	7	localClass	Class
    //   13	217	8	localObject2	Object
    //   140	163	9	localField1	Field
    //   154	161	10	localField2	Field
    //   219	41	11	localObject3	Object
    //   280	53	12	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   0	39	340	java/lang/Throwable
    //   49	56	340	java/lang/Throwable
    //   60	83	340	java/lang/Throwable
    //   86	119	340	java/lang/Throwable
    //   128	134	340	java/lang/Throwable
    //   134	162	340	java/lang/Throwable
    //   164	173	340	java/lang/Throwable
    //   176	182	340	java/lang/Throwable
    //   194	199	340	java/lang/Throwable
    //   209	249	340	java/lang/Throwable
    //   249	282	340	java/lang/Throwable
    //   287	298	340	java/lang/Throwable
    //   302	310	340	java/lang/Throwable
    //   314	322	340	java/lang/Throwable
    //   330	337	340	java/lang/Throwable
    //   351	357	340	java/lang/Throwable
    //   128	134	350	java/lang/ClassNotFoundException
    //   164	173	370	java/lang/NoSuchFieldException
  }
  
  /* Error */
  public static void monkeyPatchExistingResources(Context paramContext, String paramString, java.util.Collection<android.app.Activity> paramCollection)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +4 -> 5
    //   4: return
    //   5: ldc -111
    //   7: iconst_0
    //   8: anewarray 17	java/lang/Class
    //   11: invokevirtual 149	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   14: iconst_0
    //   15: anewarray 4	java/lang/Object
    //   18: invokevirtual 155	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   21: checkcast 145	android/content/res/AssetManager
    //   24: astore_3
    //   25: ldc -111
    //   27: ldc -99
    //   29: iconst_1
    //   30: anewarray 17	java/lang/Class
    //   33: dup
    //   34: iconst_0
    //   35: ldc 99
    //   37: aastore
    //   38: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   41: astore 4
    //   43: aload 4
    //   45: iconst_1
    //   46: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   49: aload 4
    //   51: aload_3
    //   52: iconst_1
    //   53: anewarray 4	java/lang/Object
    //   56: dup
    //   57: iconst_0
    //   58: aload_1
    //   59: aastore
    //   60: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   63: checkcast 162	java/lang/Integer
    //   66: invokevirtual 165	java/lang/Integer:intValue	()I
    //   69: ifne +23 -> 92
    //   72: new 136	java/lang/IllegalStateException
    //   75: dup
    //   76: ldc -89
    //   78: invokespecial 170	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   81: athrow
    //   82: astore_0
    //   83: new 136	java/lang/IllegalStateException
    //   86: dup
    //   87: aload_0
    //   88: invokespecial 139	java/lang/IllegalStateException:<init>	(Ljava/lang/Throwable;)V
    //   91: athrow
    //   92: ldc -111
    //   94: ldc -84
    //   96: iconst_0
    //   97: anewarray 17	java/lang/Class
    //   100: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   103: astore_1
    //   104: aload_1
    //   105: iconst_1
    //   106: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   109: aload_1
    //   110: aload_3
    //   111: iconst_0
    //   112: anewarray 4	java/lang/Object
    //   115: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   118: pop
    //   119: aload_2
    //   120: ifnull +352 -> 472
    //   123: aload_2
    //   124: invokeinterface 175 1 0
    //   129: astore_1
    //   130: aload_1
    //   131: invokeinterface 121 1 0
    //   136: ifeq +336 -> 472
    //   139: aload_1
    //   140: invokeinterface 125 1 0
    //   145: checkcast 177	android/app/Activity
    //   148: astore_2
    //   149: aload_2
    //   150: invokevirtual 181	android/app/Activity:getResources	()Landroid/content/res/Resources;
    //   153: astore 4
    //   155: ldc -73
    //   157: ldc -71
    //   159: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   162: astore 5
    //   164: aload 5
    //   166: iconst_1
    //   167: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   170: aload 5
    //   172: aload 4
    //   174: aload_3
    //   175: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   178: aload_2
    //   179: invokevirtual 189	android/app/Activity:getTheme	()Landroid/content/res/Resources$Theme;
    //   182: astore 5
    //   184: ldc -65
    //   186: ldc -71
    //   188: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   191: astore 6
    //   193: aload 6
    //   195: iconst_1
    //   196: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   199: aload 6
    //   201: aload 5
    //   203: aload_3
    //   204: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   207: ldc -63
    //   209: ldc -61
    //   211: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   214: astore 6
    //   216: aload 6
    //   218: iconst_1
    //   219: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   222: aload 6
    //   224: aload_2
    //   225: aconst_null
    //   226: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   229: ldc -63
    //   231: ldc -59
    //   233: iconst_0
    //   234: anewarray 17	java/lang/Class
    //   237: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   240: astore 6
    //   242: aload 6
    //   244: iconst_1
    //   245: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   248: aload 6
    //   250: aload_2
    //   251: iconst_0
    //   252: anewarray 4	java/lang/Object
    //   255: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   258: pop
    //   259: getstatic 203	android/os/Build$VERSION:SDK_INT	I
    //   262: bipush 24
    //   264: if_icmpge +58 -> 322
    //   267: ldc -111
    //   269: ldc -51
    //   271: iconst_0
    //   272: anewarray 17	java/lang/Class
    //   275: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   278: astore 6
    //   280: aload 6
    //   282: iconst_1
    //   283: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   286: aload 6
    //   288: aload_3
    //   289: iconst_0
    //   290: anewarray 4	java/lang/Object
    //   293: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   296: astore 6
    //   298: ldc -65
    //   300: ldc -61
    //   302: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   305: astore 7
    //   307: aload 7
    //   309: iconst_1
    //   310: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   313: aload 7
    //   315: aload 5
    //   317: aload 6
    //   319: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   322: aload 4
    //   324: invokestatic 209	com/android/tools/fd/runtime/MonkeyPatcher:pruneResourceCaches	(Ljava/lang/Object;)V
    //   327: goto -197 -> 130
    //   330: astore 5
    //   332: ldc -73
    //   334: ldc -45
    //   336: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   339: astore 5
    //   341: aload 5
    //   343: iconst_1
    //   344: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   347: aload 5
    //   349: aload 4
    //   351: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   354: astore 5
    //   356: aload 5
    //   358: invokevirtual 41	java/lang/Object:getClass	()Ljava/lang/Class;
    //   361: ldc -71
    //   363: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   366: astore 6
    //   368: aload 6
    //   370: iconst_1
    //   371: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   374: aload 6
    //   376: aload 5
    //   378: aload_3
    //   379: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   382: goto -204 -> 178
    //   385: astore 6
    //   387: ldc -65
    //   389: ldc -43
    //   391: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   394: astore 6
    //   396: aload 6
    //   398: iconst_1
    //   399: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   402: aload 6
    //   404: aload 5
    //   406: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   409: astore 6
    //   411: aload 6
    //   413: invokevirtual 41	java/lang/Object:getClass	()Ljava/lang/Class;
    //   416: ldc -71
    //   418: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   421: astore 7
    //   423: aload 7
    //   425: iconst_1
    //   426: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   429: aload 7
    //   431: aload 6
    //   433: aload_3
    //   434: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   437: goto -230 -> 207
    //   440: astore 5
    //   442: ldc -41
    //   444: new 217	java/lang/StringBuilder
    //   447: dup
    //   448: invokespecial 218	java/lang/StringBuilder:<init>	()V
    //   451: ldc -36
    //   453: invokevirtual 224	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   456: aload_2
    //   457: invokevirtual 227	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   460: invokevirtual 231	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   463: aload 5
    //   465: invokestatic 237	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   468: pop
    //   469: goto -147 -> 322
    //   472: getstatic 203	android/os/Build$VERSION:SDK_INT	I
    //   475: bipush 19
    //   477: if_icmplt +155 -> 632
    //   480: ldc -17
    //   482: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   485: astore_1
    //   486: aload_1
    //   487: ldc -15
    //   489: iconst_0
    //   490: anewarray 17	java/lang/Class
    //   493: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   496: astore_0
    //   497: aload_0
    //   498: iconst_1
    //   499: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   502: aload_0
    //   503: aconst_null
    //   504: iconst_0
    //   505: anewarray 4	java/lang/Object
    //   508: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   511: astore_2
    //   512: aload_1
    //   513: ldc -13
    //   515: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   518: astore_0
    //   519: aload_0
    //   520: iconst_1
    //   521: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   524: aload_0
    //   525: aload_2
    //   526: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   529: checkcast 245	android/util/ArrayMap
    //   532: invokevirtual 249	android/util/ArrayMap:values	()Ljava/util/Collection;
    //   535: astore_0
    //   536: aload_0
    //   537: invokeinterface 175 1 0
    //   542: astore_0
    //   543: aload_0
    //   544: invokeinterface 121 1 0
    //   549: ifeq -545 -> 4
    //   552: aload_0
    //   553: invokeinterface 125 1 0
    //   558: checkcast 132	java/lang/ref/WeakReference
    //   561: invokevirtual 134	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
    //   564: checkcast 183	android/content/res/Resources
    //   567: astore_1
    //   568: aload_1
    //   569: ifnull -26 -> 543
    //   572: ldc -73
    //   574: ldc -71
    //   576: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   579: astore_2
    //   580: aload_2
    //   581: iconst_1
    //   582: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   585: aload_2
    //   586: aload_1
    //   587: aload_3
    //   588: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   591: aload_1
    //   592: aload_1
    //   593: invokevirtual 253	android/content/res/Resources:getConfiguration	()Landroid/content/res/Configuration;
    //   596: aload_1
    //   597: invokevirtual 257	android/content/res/Resources:getDisplayMetrics	()Landroid/util/DisplayMetrics;
    //   600: invokevirtual 261	android/content/res/Resources:updateConfiguration	(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V
    //   603: goto -60 -> 543
    //   606: astore_0
    //   607: aload_1
    //   608: ldc_w 263
    //   611: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   614: astore_0
    //   615: aload_0
    //   616: iconst_1
    //   617: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   620: aload_0
    //   621: aload_2
    //   622: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   625: checkcast 174	java/util/Collection
    //   628: astore_0
    //   629: goto -93 -> 536
    //   632: ldc 15
    //   634: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   637: astore_1
    //   638: aload_1
    //   639: ldc -13
    //   641: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   644: astore_2
    //   645: aload_2
    //   646: iconst_1
    //   647: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   650: aload_2
    //   651: aload_0
    //   652: aload_1
    //   653: invokestatic 69	com/android/tools/fd/runtime/MonkeyPatcher:getActivityThread	(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    //   656: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   659: checkcast 265	java/util/HashMap
    //   662: invokevirtual 266	java/util/HashMap:values	()Ljava/util/Collection;
    //   665: astore_0
    //   666: goto -130 -> 536
    //   669: astore_2
    //   670: ldc -73
    //   672: ldc -45
    //   674: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   677: astore_2
    //   678: aload_2
    //   679: iconst_1
    //   680: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   683: aload_2
    //   684: aload_1
    //   685: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   688: astore_2
    //   689: aload_2
    //   690: invokevirtual 41	java/lang/Object:getClass	()Ljava/lang/Class;
    //   693: ldc -71
    //   695: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   698: astore 4
    //   700: aload 4
    //   702: iconst_1
    //   703: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   706: aload 4
    //   708: aload_2
    //   709: aload_3
    //   710: invokevirtual 77	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   713: goto -122 -> 591
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	716	0	paramContext	Context
    //   0	716	1	paramString	String
    //   0	716	2	paramCollection	java.util.Collection<android.app.Activity>
    //   24	686	3	localAssetManager	android.content.res.AssetManager
    //   41	666	4	localObject1	Object
    //   162	154	5	localObject2	Object
    //   330	1	5	localThrowable1	Throwable
    //   339	66	5	localObject3	Object
    //   440	24	5	localThrowable2	Throwable
    //   191	184	6	localObject4	Object
    //   385	1	6	localNoSuchFieldException	NoSuchFieldException
    //   394	38	6	localObject5	Object
    //   305	125	7	localField	Field
    // Exception table:
    //   from	to	target	type
    //   5	82	82	java/lang/Throwable
    //   92	119	82	java/lang/Throwable
    //   123	130	82	java/lang/Throwable
    //   130	155	82	java/lang/Throwable
    //   178	184	82	java/lang/Throwable
    //   322	327	82	java/lang/Throwable
    //   332	382	82	java/lang/Throwable
    //   442	469	82	java/lang/Throwable
    //   472	512	82	java/lang/Throwable
    //   512	536	82	java/lang/Throwable
    //   536	543	82	java/lang/Throwable
    //   543	568	82	java/lang/Throwable
    //   591	603	82	java/lang/Throwable
    //   607	629	82	java/lang/Throwable
    //   632	666	82	java/lang/Throwable
    //   670	713	82	java/lang/Throwable
    //   155	178	330	java/lang/Throwable
    //   184	207	385	java/lang/NoSuchFieldException
    //   184	207	440	java/lang/Throwable
    //   207	322	440	java/lang/Throwable
    //   387	437	440	java/lang/Throwable
    //   512	536	606	java/lang/NoSuchFieldException
    //   572	591	669	java/lang/Throwable
  }
  
  /* Error */
  private static boolean pruneResourceCache(Object paramObject, String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 41	java/lang/Object:getClass	()Ljava/lang/Class;
    //   4: astore 5
    //   6: aload 5
    //   8: aload_1
    //   9: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   12: astore 5
    //   14: aload 5
    //   16: iconst_1
    //   17: invokevirtual 50	java/lang/reflect/Field:setAccessible	(Z)V
    //   20: aload 5
    //   22: aload_0
    //   23: invokevirtual 54	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   26: astore 7
    //   28: aload 5
    //   30: invokevirtual 274	java/lang/reflect/Field:getType	()Ljava/lang/Class;
    //   33: astore 6
    //   35: getstatic 203	android/os/Build$VERSION:SDK_INT	I
    //   38: bipush 16
    //   40: if_icmpge +60 -> 100
    //   43: aload 7
    //   45: instanceof 276
    //   48: ifeq +26 -> 74
    //   51: aload 7
    //   53: checkcast 276	android/util/SparseArray
    //   56: invokevirtual 279	android/util/SparseArray:clear	()V
    //   59: iconst_1
    //   60: ireturn
    //   61: astore 5
    //   63: ldc -73
    //   65: aload_1
    //   66: invokevirtual 59	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   69: astore 5
    //   71: goto -57 -> 14
    //   74: getstatic 203	android/os/Build$VERSION:SDK_INT	I
    //   77: bipush 14
    //   79: if_icmplt +330 -> 409
    //   82: aload 7
    //   84: instanceof 281
    //   87: ifeq +322 -> 409
    //   90: aload 7
    //   92: checkcast 281	android/util/LongSparseArray
    //   95: invokevirtual 282	android/util/LongSparseArray:clear	()V
    //   98: iconst_1
    //   99: ireturn
    //   100: aload 6
    //   102: astore 5
    //   104: getstatic 203	android/os/Build$VERSION:SDK_INT	I
    //   107: bipush 23
    //   109: if_icmpge +247 -> 356
    //   112: ldc_w 284
    //   115: aload_1
    //   116: invokevirtual 288	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   119: ifeq +22 -> 141
    //   122: aload 7
    //   124: instanceof 281
    //   127: ifeq +282 -> 409
    //   130: aload 7
    //   132: checkcast 281	android/util/LongSparseArray
    //   135: invokevirtual 282	android/util/LongSparseArray:clear	()V
    //   138: goto +271 -> 409
    //   141: aload 6
    //   143: ldc -11
    //   145: invokevirtual 292	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   148: ifeq +56 -> 204
    //   151: ldc -73
    //   153: ldc_w 294
    //   156: iconst_2
    //   157: anewarray 17	java/lang/Class
    //   160: dup
    //   161: iconst_0
    //   162: ldc -11
    //   164: aastore
    //   165: dup
    //   166: iconst_1
    //   167: getstatic 298	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   170: aastore
    //   171: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   174: astore_1
    //   175: aload_1
    //   176: iconst_1
    //   177: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   180: aload_1
    //   181: aload_0
    //   182: iconst_2
    //   183: anewarray 4	java/lang/Object
    //   186: dup
    //   187: iconst_0
    //   188: aload 7
    //   190: aastore
    //   191: dup
    //   192: iconst_1
    //   193: iconst_m1
    //   194: invokestatic 302	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   197: aastore
    //   198: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   201: pop
    //   202: iconst_1
    //   203: ireturn
    //   204: aload 6
    //   206: ldc_w 281
    //   209: invokevirtual 292	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   212: istore 4
    //   214: iload 4
    //   216: ifeq +76 -> 292
    //   219: ldc -73
    //   221: ldc_w 294
    //   224: iconst_2
    //   225: anewarray 17	java/lang/Class
    //   228: dup
    //   229: iconst_0
    //   230: ldc_w 281
    //   233: aastore
    //   234: dup
    //   235: iconst_1
    //   236: getstatic 298	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   239: aastore
    //   240: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   243: astore_1
    //   244: aload_1
    //   245: iconst_1
    //   246: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   249: aload_1
    //   250: aload_0
    //   251: iconst_2
    //   252: anewarray 4	java/lang/Object
    //   255: dup
    //   256: iconst_0
    //   257: aload 7
    //   259: aastore
    //   260: dup
    //   261: iconst_1
    //   262: iconst_m1
    //   263: invokestatic 302	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   266: aastore
    //   267: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   270: pop
    //   271: iconst_1
    //   272: ireturn
    //   273: astore_0
    //   274: aload 7
    //   276: instanceof 281
    //   279: ifeq +130 -> 409
    //   282: aload 7
    //   284: checkcast 281	android/util/LongSparseArray
    //   287: invokevirtual 282	android/util/LongSparseArray:clear	()V
    //   290: iconst_1
    //   291: ireturn
    //   292: aload 6
    //   294: invokevirtual 305	java/lang/Class:isArray	()Z
    //   297: ifeq +112 -> 409
    //   300: aload 6
    //   302: invokevirtual 308	java/lang/Class:getComponentType	()Ljava/lang/Class;
    //   305: ldc_w 281
    //   308: invokevirtual 292	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   311: ifeq +98 -> 409
    //   314: aload 7
    //   316: checkcast 310	[Landroid/util/LongSparseArray;
    //   319: checkcast 310	[Landroid/util/LongSparseArray;
    //   322: astore_0
    //   323: aload_0
    //   324: arraylength
    //   325: istore_3
    //   326: iconst_0
    //   327: istore_2
    //   328: iload_2
    //   329: iload_3
    //   330: if_icmpge +88 -> 418
    //   333: aload_0
    //   334: iload_2
    //   335: aaload
    //   336: astore_1
    //   337: aload_1
    //   338: ifnull +73 -> 411
    //   341: aload_1
    //   342: invokevirtual 282	android/util/LongSparseArray:clear	()V
    //   345: goto +66 -> 411
    //   348: astore_0
    //   349: aload 5
    //   351: invokevirtual 313	java/lang/Class:getSuperclass	()Ljava/lang/Class;
    //   354: astore 5
    //   356: aload 5
    //   358: ifnull +51 -> 409
    //   361: aload 5
    //   363: ldc_w 315
    //   366: iconst_1
    //   367: anewarray 17	java/lang/Class
    //   370: dup
    //   371: iconst_0
    //   372: getstatic 298	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   375: aastore
    //   376: invokevirtual 160	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   379: astore_0
    //   380: aload_0
    //   381: iconst_1
    //   382: invokevirtual 33	java/lang/reflect/Method:setAccessible	(Z)V
    //   385: aload_0
    //   386: aload 7
    //   388: iconst_1
    //   389: anewarray 4	java/lang/Object
    //   392: dup
    //   393: iconst_0
    //   394: iconst_m1
    //   395: invokestatic 302	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   398: aastore
    //   399: invokevirtual 37	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   402: pop
    //   403: iconst_1
    //   404: ireturn
    //   405: astore_0
    //   406: goto +3 -> 409
    //   409: iconst_0
    //   410: ireturn
    //   411: iload_2
    //   412: iconst_1
    //   413: iadd
    //   414: istore_2
    //   415: goto -87 -> 328
    //   418: iconst_1
    //   419: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	420	0	paramObject	Object
    //   0	420	1	paramString	String
    //   327	88	2	i	int
    //   325	6	3	j	int
    //   212	3	4	bool	boolean
    //   4	25	5	localObject1	Object
    //   61	1	5	localNoSuchFieldException	NoSuchFieldException
    //   69	293	5	localObject2	Object
    //   33	268	6	localClass	Class
    //   26	361	7	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   6	14	61	java/lang/NoSuchFieldException
    //   219	271	273	java/lang/NoSuchMethodException
    //   361	403	348	java/lang/Throwable
    //   0	6	405	java/lang/Throwable
    //   6	14	405	java/lang/Throwable
    //   14	59	405	java/lang/Throwable
    //   63	71	405	java/lang/Throwable
    //   74	98	405	java/lang/Throwable
    //   104	138	405	java/lang/Throwable
    //   141	202	405	java/lang/Throwable
    //   204	214	405	java/lang/Throwable
    //   219	271	405	java/lang/Throwable
    //   274	290	405	java/lang/Throwable
    //   292	326	405	java/lang/Throwable
    //   341	345	405	java/lang/Throwable
    //   349	356	405	java/lang/Throwable
  }
  
  private static void pruneResourceCaches(Object paramObject)
  {
    if (Build.VERSION.SDK_INT >= 21) {}
    try
    {
      localObject1 = Resources.class.getDeclaredField("mTypedArrayPool");
      ((Field)localObject1).setAccessible(true);
      localObject1 = ((Field)localObject1).get(paramObject);
      ??? = localObject1.getClass().getDeclaredMethod("acquire", new Class[0]);
      ((Method)???).setAccessible(true);
      Object localObject4;
      do
      {
        localObject4 = ((Method)???).invoke(localObject1, new Object[0]);
      } while (localObject4 != null);
    }
    catch (Throwable localThrowable2)
    {
      Object localObject1;
      for (;;) {}
    }
    localObject1 = paramObject;
    if (Build.VERSION.SDK_INT >= 23) {}
    try
    {
      localObject1 = Resources.class.getDeclaredField("mResourcesImpl");
      ((Field)localObject1).setAccessible(true);
      localObject1 = ((Field)localObject1).get(paramObject);
      paramObject = null;
      if (Build.VERSION.SDK_INT >= 18) {}
      for (;;)
      {
        try
        {
          ??? = localObject1.getClass().getDeclaredField("mAccessLock");
          ((Field)???).setAccessible(true);
          ??? = ((Field)???).get(localObject1);
          paramObject = ???;
        }
        catch (Throwable localThrowable4)
        {
          continue;
        }
        ??? = paramObject;
        if (paramObject == null) {}
        synchronized (MonkeyPatcher.class)
        {
          pruneResourceCache(localObject1, "mDrawableCache");
          pruneResourceCache(localObject1, "mColorDrawableCache");
          pruneResourceCache(localObject1, "mColorStateListCache");
          if (Build.VERSION.SDK_INT >= 23)
          {
            pruneResourceCache(localObject1, "mAnimatorCache");
            pruneResourceCache(localObject1, "mStateListAnimatorCache");
            return;
          }
          try
          {
            ??? = Resources.class.getDeclaredField("mTmpValue");
            ((Field)???).setAccessible(true);
            ??? = ((Field)???).get(localObject1);
            paramObject = ???;
          }
          catch (Throwable localThrowable3) {}
          if (Build.VERSION.SDK_INT == 19)
          {
            pruneResourceCache(localObject1, "sPreloadedDrawables");
            pruneResourceCache(localObject1, "sPreloadedColorDrawables");
            pruneResourceCache(localObject1, "sPreloadedColorStateLists");
          }
        }
      }
    }
    catch (Throwable localThrowable1)
    {
      for (;;)
      {
        Object localObject2 = paramObject;
      }
    }
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\MonkeyPatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */