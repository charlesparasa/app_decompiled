package com.android.tools.fd.runtime;

public class PatchesLoaderDumper
{
  public static void main(String[] paramArrayOfString)
  {
    try
    {
      ((PatchesLoader)Class.forName("com.android.tools.fd.runtime.AppPatchesLoaderImpl").newInstance()).load();
      return;
    }
    catch (ClassNotFoundException paramArrayOfString)
    {
      paramArrayOfString.printStackTrace();
      return;
    }
    catch (InstantiationException paramArrayOfString)
    {
      paramArrayOfString.printStackTrace();
      return;
    }
    catch (IllegalAccessException paramArrayOfString)
    {
      paramArrayOfString.printStackTrace();
    }
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\PatchesLoaderDumper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */