package com.android.tools.fd.runtime;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.app.Application.OnProvideAssistDataListener;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Process;
import android.util.Log;
import com.android.tools.fd.common.Log.Logging;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

public class BootstrapApplication
  extends Application
{
  public static final String LOG_TAG = "InstantRun";
  private String externalResourcePath;
  private Application realApplication;
  
  static
  {
    com.android.tools.fd.common.Log.logging = new Log.Logging()
    {
      public boolean isLoggable(Level paramAnonymousLevel)
      {
        if (paramAnonymousLevel == Level.SEVERE) {
          return Log.isLoggable("InstantRun", 6);
        }
        if (paramAnonymousLevel == Level.FINE) {
          return Log.isLoggable("InstantRun", 2);
        }
        return Log.isLoggable("InstantRun", 4);
      }
      
      public void log(Level paramAnonymousLevel, String paramAnonymousString)
      {
        log(paramAnonymousLevel, paramAnonymousString, null);
      }
      
      public void log(Level paramAnonymousLevel, String paramAnonymousString, Throwable paramAnonymousThrowable)
      {
        if (paramAnonymousLevel == Level.SEVERE) {
          if (paramAnonymousThrowable == null) {
            Log.e("InstantRun", paramAnonymousString);
          }
        }
        do
        {
          do
          {
            return;
            Log.e("InstantRun", paramAnonymousString, paramAnonymousThrowable);
            return;
            if (paramAnonymousLevel != Level.FINE) {
              break;
            }
          } while (!Log.isLoggable("InstantRun", 2));
          if (paramAnonymousThrowable == null)
          {
            Log.v("InstantRun", paramAnonymousString);
            return;
          }
          Log.v("InstantRun", paramAnonymousString, paramAnonymousThrowable);
          return;
        } while (!Log.isLoggable("InstantRun", 4));
        if (paramAnonymousThrowable == null)
        {
          Log.i("InstantRun", paramAnonymousString);
          return;
        }
        Log.i("InstantRun", paramAnonymousString, paramAnonymousThrowable);
      }
    };
  }
  
  public BootstrapApplication()
  {
    Log.i("InstantRun", String.format("Instant Run Runtime started. Android package is %s, real application class is %s.", new Object[] { AppInfo.applicationId, AppInfo.applicationClass }));
  }
  
  private void createRealApplication()
  {
    if (AppInfo.applicationClass != null)
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "About to create real application of class name = " + AppInfo.applicationClass);
      }
      try
      {
        Class localClass = Class.forName(AppInfo.applicationClass);
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Created delegate app class successfully : " + localClass + " with class loader " + localClass.getClassLoader());
        }
        this.realApplication = ((Application)localClass.getConstructor(new Class[0]).newInstance(new Object[0]));
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Created real app instance successfully :" + this.realApplication);
        }
        return;
      }
      catch (Exception localException)
      {
        throw new IllegalStateException(localException);
      }
    }
    this.realApplication = new Application();
  }
  
  private void createResources(long paramLong)
  {
    String str = null;
    FileManager.checkInbox();
    Object localObject = FileManager.getExternalResourceFile();
    if (localObject != null) {
      str = ((File)localObject).getPath();
    }
    this.externalResourcePath = str;
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "Resource override is " + this.externalResourcePath);
    }
    if (localObject != null)
    {
      long l;
      do
      {
        try
        {
          l = ((File)localObject).lastModified();
          if (Log.isLoggable("InstantRun", 2))
          {
            Log.v("InstantRun", "Resource patch last modified: " + l);
            localObject = new StringBuilder().append("APK last modified: ").append(paramLong).append(" ");
            if (paramLong > l)
            {
              str = ">";
              Log.v("InstantRun", str + " resource patch");
            }
          }
          while (paramLong == 0L)
          {
            if (Log.isLoggable("InstantRun", 2)) {
              Log.v("InstantRun", "Ignoring resource file, older than APK");
            }
            this.externalResourcePath = null;
            return;
            str = "<";
            break;
          }
        }
        catch (Throwable localThrowable)
        {
          Log.e("InstantRun", "Failed to check patch timestamps", localThrowable);
          return;
        }
      } while (l <= paramLong);
    }
  }
  
  public static String join(char paramChar, List<String> paramList)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    paramList = paramList.iterator();
    while (paramList.hasNext()) {
      localStringBuilder.append((String)paramList.next()).append(paramChar);
    }
    localStringBuilder.deleteCharAt(localStringBuilder.length() - 1);
    return localStringBuilder.toString();
  }
  
  private static void setupClassLoaders(Context paramContext, String paramString, long paramLong)
  {
    List localList = FileManager.getDexList(paramContext, paramLong);
    if (!localList.isEmpty())
    {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Bootstrapping class loader with dex list " + join('\n', localList));
      }
      ClassLoader localClassLoader = BootstrapApplication.class.getClassLoader();
      try
      {
        String str = (String)localClassLoader.getClass().getMethod("getLdLibraryPath", new Class[0]).invoke(localClassLoader, new Object[0]);
        paramContext = str;
        if (Log.isLoggable("InstantRun", 2))
        {
          Log.v("InstantRun", "Native library path: " + str);
          paramContext = str;
        }
      }
      catch (Throwable paramContext)
      {
        for (;;)
        {
          Log.e("InstantRun", "Failed to determine native library path " + paramContext.getMessage());
          paramContext = FileManager.getNativeLibraryFolder().getPath();
        }
      }
      IncrementalClassLoader.inject(localClassLoader, paramContext, paramString, localList);
      return;
    }
    Log.w("InstantRun", "No instant run dex files added to classpath");
  }
  
  protected void attachBaseContext(Context paramContext)
  {
    Object localObject;
    if (!AppInfo.usingApkSplits)
    {
      localObject = paramContext.getApplicationInfo().sourceDir;
      if (localObject == null) {
        break label111;
      }
    }
    for (long l = new File((String)localObject).lastModified();; l = 0L)
    {
      createResources(l);
      setupClassLoaders(paramContext, paramContext.getCacheDir().getPath(), l);
      createRealApplication();
      super.attachBaseContext(paramContext);
      if (this.realApplication != null) {}
      try
      {
        localObject = ContextWrapper.class.getDeclaredMethod("attachBaseContext", new Class[] { Context.class });
        ((Method)localObject).setAccessible(true);
        ((Method)localObject).invoke(this.realApplication, new Object[] { paramContext });
        return;
      }
      catch (Exception paramContext)
      {
        label111:
        throw new IllegalStateException(paramContext);
      }
    }
  }
  
  public Context createPackageContext(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    Context localContext = this.realApplication.createPackageContext(paramString, paramInt);
    paramString = localContext;
    if (localContext == null) {
      paramString = this.realApplication;
    }
    return paramString;
  }
  
  public void onCreate()
  {
    if (!AppInfo.usingApkSplits)
    {
      MonkeyPatcher.monkeyPatchApplication(this, this, this.realApplication, this.externalResourcePath);
      MonkeyPatcher.monkeyPatchExistingResources(this, this.externalResourcePath, null);
      super.onCreate();
      if (AppInfo.applicationId == null) {}
    }
    for (int j = 0;; j = 1)
    {
      try
      {
        int n = Process.myPid();
        Object localObject = ((ActivityManager)getSystemService("activity")).getRunningAppProcesses();
        if ((localObject == null) || (((List)localObject).size() <= 1)) {
          continue;
        }
        int m = 0;
        localObject = ((List)localObject).iterator();
        int k;
        ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo;
        do
        {
          do
          {
            k = j;
            i = m;
            if (!((Iterator)localObject).hasNext()) {
              break;
            }
            localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)((Iterator)localObject).next();
          } while (!AppInfo.applicationId.equals(localRunningAppProcessInfo.processName));
          k = 1;
          j = 1;
        } while (localRunningAppProcessInfo.pid != n);
        int i = 1;
        j = i;
        if (i == 0)
        {
          j = i;
          if (k == 0)
          {
            i = 1;
            j = i;
            if (Log.isLoggable("InstantRun", 2))
            {
              Log.v("InstantRun", "Multiprocess but didn't find process with package: starting server anyway");
              j = i;
            }
          }
        }
        if (j != 0) {
          Server.create(AppInfo.applicationId, this);
        }
      }
      catch (Throwable localThrowable)
      {
        for (;;)
        {
          if (Log.isLoggable("InstantRun", 2)) {
            Log.v("InstantRun", "Failed during multi process check", localThrowable);
          }
          Server.create(AppInfo.applicationId, this);
        }
      }
      if (this.realApplication != null) {
        this.realApplication.onCreate();
      }
      return;
      MonkeyPatcher.monkeyPatchApplication(this, this, this.realApplication, null);
      break;
    }
  }
  
  public void registerActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks paramActivityLifecycleCallbacks)
  {
    this.realApplication.registerActivityLifecycleCallbacks(paramActivityLifecycleCallbacks);
  }
  
  public void registerComponentCallbacks(ComponentCallbacks paramComponentCallbacks)
  {
    this.realApplication.registerComponentCallbacks(paramComponentCallbacks);
  }
  
  public void registerOnProvideAssistDataListener(Application.OnProvideAssistDataListener paramOnProvideAssistDataListener)
  {
    this.realApplication.registerOnProvideAssistDataListener(paramOnProvideAssistDataListener);
  }
  
  public void unregisterActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks paramActivityLifecycleCallbacks)
  {
    this.realApplication.unregisterActivityLifecycleCallbacks(paramActivityLifecycleCallbacks);
  }
  
  public void unregisterComponentCallbacks(ComponentCallbacks paramComponentCallbacks)
  {
    this.realApplication.unregisterComponentCallbacks(paramComponentCallbacks);
  }
  
  public void unregisterOnProvideAssistDataListener(Application.OnProvideAssistDataListener paramOnProvideAssistDataListener)
  {
    this.realApplication.unregisterOnProvideAssistDataListener(paramOnProvideAssistDataListener);
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\BootstrapApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */