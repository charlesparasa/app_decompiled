package com.android.tools.fd.runtime;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Restarter
{
  public static List<Activity> getActivities(Context paramContext, boolean paramBoolean)
  {
    localArrayList = new ArrayList();
    try
    {
      Object localObject1 = Class.forName("android.app.ActivityThread");
      paramContext = MonkeyPatcher.getActivityThread(paramContext, (Class)localObject1);
      localObject1 = ((Class)localObject1).getDeclaredField("mActivities");
      ((Field)localObject1).setAccessible(true);
      paramContext = ((Field)localObject1).get(paramContext);
      if ((paramContext instanceof HashMap)) {}
      for (paramContext = ((HashMap)paramContext).values();; paramContext = ((ArrayMap)paramContext).values())
      {
        paramContext = paramContext.iterator();
        while (paramContext.hasNext())
        {
          localObject1 = paramContext.next();
          Object localObject2 = localObject1.getClass();
          if (paramBoolean)
          {
            Field localField = ((Class)localObject2).getDeclaredField("paused");
            localField.setAccessible(true);
            if (localField.getBoolean(localObject1)) {}
          }
          else
          {
            localObject2 = ((Class)localObject2).getDeclaredField("activity");
            ((Field)localObject2).setAccessible(true);
            localObject1 = (Activity)((Field)localObject2).get(localObject1);
            if (localObject1 != null) {
              localArrayList.add(localObject1);
            }
          }
        }
        if ((Build.VERSION.SDK_INT < 19) || (!(paramContext instanceof ArrayMap))) {
          break;
        }
      }
      return localArrayList;
    }
    catch (Throwable paramContext) {}
  }
  
  public static Activity getForegroundActivity(Context paramContext)
  {
    paramContext = getActivities(paramContext, true);
    if (paramContext.isEmpty()) {
      return null;
    }
    return (Activity)paramContext.get(0);
  }
  
  private static void restartActivity(Activity paramActivity)
  {
    Activity localActivity = paramActivity;
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "About to restart " + paramActivity.getClass().getSimpleName());
    }
    for (localActivity = paramActivity; localActivity.getParent() != null; localActivity = localActivity.getParent()) {
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", localActivity.getClass().getSimpleName() + " is not a top level activity; restarting " + localActivity.getParent().getClass().getSimpleName() + " instead");
      }
    }
    localActivity.recreate();
  }
  
  public static void restartActivityOnUiThread(Activity paramActivity)
  {
    paramActivity.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (Log.isLoggable("InstantRun", 2)) {
          Log.v("InstantRun", "Resources updated: notify activities");
        }
        Restarter.updateActivity(this.val$activity);
      }
    });
  }
  
  public static void restartApp(Context paramContext, Collection<Activity> paramCollection, boolean paramBoolean)
  {
    if (!paramCollection.isEmpty())
    {
      paramContext = getForegroundActivity(paramContext);
      if (paramContext == null) {
        break label130;
      }
      if (paramBoolean) {
        showToast(paramContext, "Restarting app to apply incompatible changes");
      }
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "RESTARTING APP");
      }
      paramCollection = PendingIntent.getActivity(paramContext, 0, new Intent(paramContext, paramContext.getClass()), 268435456);
      ((AlarmManager)paramContext.getSystemService("alarm")).set(1, System.currentTimeMillis() + 100L, paramCollection);
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Scheduling activity " + paramContext + " to start after exiting process");
      }
    }
    for (;;)
    {
      System.exit(0);
      return;
      label130:
      showToast((Activity)paramCollection.iterator().next(), "Unable to restart app");
      if (Log.isLoggable("InstantRun", 2)) {
        Log.v("InstantRun", "Couldn't find any foreground activities to restart for resource refresh");
      }
    }
  }
  
  static void showToast(Activity paramActivity, final String paramString)
  {
    if (Log.isLoggable("InstantRun", 2)) {
      Log.v("InstantRun", "About to show toast for activity " + paramActivity + ": " + paramString);
    }
    paramActivity.runOnUiThread(new Runnable()
    {
      public void run()
      {
        for (;;)
        {
          try
          {
            Context localContext = this.val$activity.getApplicationContext();
            if (((localContext instanceof ContextWrapper)) && (((ContextWrapper)localContext).getBaseContext() == null))
            {
              if (Log.isLoggable("InstantRun", 5)) {
                Log.w("InstantRun", "Couldn't show toast: no base context");
              }
            }
            else
            {
              i = 0;
              if ((paramString.length() >= 60) || (paramString.indexOf('\n') != -1)) {
                break label109;
              }
              Toast.makeText(this.val$activity, paramString, i).show();
              return;
            }
          }
          catch (Throwable localThrowable)
          {
            if (Log.isLoggable("InstantRun", 5)) {
              Log.w("InstantRun", "Couldn't show toast", localThrowable);
            }
          }
          return;
          label109:
          int i = 1;
        }
      }
    });
  }
  
  public static void showToastWhenPossible(Context paramContext, String paramString)
  {
    Activity localActivity = getForegroundActivity(paramContext);
    if (localActivity != null)
    {
      showToast(localActivity, paramString);
      return;
    }
    showToastWhenPossible(paramContext, paramString, 10);
  }
  
  private static void showToastWhenPossible(Context paramContext, final String paramString, final int paramInt)
  {
    new Handler(Looper.getMainLooper()).postDelayed(new Runnable()
    {
      public void run()
      {
        Activity localActivity = Restarter.getForegroundActivity(this.val$context);
        if (localActivity != null) {
          Restarter.showToast(localActivity, paramString);
        }
        while (paramInt <= 0) {
          return;
        }
        Restarter.showToastWhenPossible(this.val$context, paramString, paramInt - 1);
      }
    }, 1000L);
  }
  
  private static void updateActivity(Activity paramActivity)
  {
    restartActivity(paramActivity);
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\runtime\Restarter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */