package com.android.tools.fd.common;

import java.util.logging.Level;

public class Log
{
  public static Logging logging = null;
  
  public static abstract interface Logging
  {
    public abstract boolean isLoggable(Level paramLevel);
    
    public abstract void log(Level paramLevel, String paramString);
    
    public abstract void log(Level paramLevel, String paramString, Throwable paramThrowable);
  }
}


/* Location:              C:\Users\knight\Downloads\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\android\tools\fd\common\Log.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */